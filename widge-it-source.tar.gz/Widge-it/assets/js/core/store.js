/* ── Namespaced, crash-proof localStorage ───────────────────────────────── */
const PREFIX = 'widgeit:';

function safeGet(key) {
  try { return localStorage.getItem(PREFIX + key); } catch { return null; }
}
function safeSet(key, value) {
  try { localStorage.setItem(PREFIX + key, value); } catch { /* quota / private mode */ }
}
function safeDel(key) {
  try { localStorage.removeItem(PREFIX + key); } catch { /* ignore */ }
}

export const store = {
  get(key, fallback = null) {
    const raw = safeGet(key);
    if (raw == null) return fallback;
    try { return JSON.parse(raw); } catch { return fallback; }
  },
  set(key, value) { safeSet(key, JSON.stringify(value)); },
  del(key) { safeDel(key); },
  /** A store scoped to one widget, so ids can't collide. */
  scoped(ns) {
    return {
      get: (k, f = null) => store.get(`${ns}.${k}`, f),
      set: (k, v) => store.set(`${ns}.${k}`, v),
      del: (k) => store.del(`${ns}.${k}`),
    };
  },
};
