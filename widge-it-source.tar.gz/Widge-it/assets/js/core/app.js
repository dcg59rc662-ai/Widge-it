/* ── Application shell: mounts widgets, handles filter / layout / theme ─── */
import { $, $$, el, icon } from './util.js';
import { store } from './store.js';
import { allWidgets, categories } from './registry.js';
import '../widgets/index.js';   // registers every widget

const board     = $('#board');
const emptyNote = $('#empty');
const chipsBar  = $('#chips');
const searchBox = $('#search');
const countNote = $('#count');

const ICONS = {
  handle: icon('<circle cx="9" cy="6" r="1.2"/><circle cx="15" cy="6" r="1.2"/><circle cx="9" cy="12" r="1.2"/><circle cx="15" cy="12" r="1.2"/><circle cx="9" cy="18" r="1.2"/><circle cx="15" cy="18" r="1.2"/>'),
  hide:   icon('<path d="M5 12h14"/>'),
};

const state = {
  query: '',
  category: store.get('ui.category', 'All'),
  hidden: new Set(store.get('layout.hidden', [])),
  order: store.get('layout.order', []),
};

const live = new Map();   // widget id -> { card, ctx }

/* ── Widget context: every side effect registers its own cleanup ────────── */
function makeContext(def) {
  const cleanups = [];
  const ctx = {
    id: def.id,
    store: store.scoped(def.id),

    /** setInterval that fires immediately and cleans itself up. */
    every(ms, fn) {
      fn();
      const id = setInterval(fn, ms);
      cleanups.push(() => clearInterval(id));
      return () => clearInterval(id);
    },

    timeout(ms, fn) {
      const id = setTimeout(fn, ms);
      cleanups.push(() => clearTimeout(id));
      return () => clearTimeout(id);
    },

    /** True while this card is on screen and the tab is in the foreground. */
    visible: true,

    /**
     * requestAnimationFrame loop that idles while the tab is hidden or the
     * card is scrolled out of view — 30 widgets animating at once otherwise
     * costs real frame budget.
     */
    frame(fn) {
      let raf = 0;
      const loop = (t) => {
        raf = requestAnimationFrame(loop);
        if (document.hidden || !ctx.visible) return;
        fn(t);
      };
      raf = requestAnimationFrame(loop);
      cleanups.push(() => cancelAnimationFrame(raf));
      return () => cancelAnimationFrame(raf);
    },

    /** Run once on the next frame, after layout has settled. */
    next(fn) {
      const raf = requestAnimationFrame(fn);
      cleanups.push(() => cancelAnimationFrame(raf));
    },

    on(target, type, handler, opts) {
      target.addEventListener(type, handler, opts);
      cleanups.push(() => target.removeEventListener(type, handler, opts));
    },

    /** Re-run when the colour theme flips (canvas widgets need this). */
    onTheme(fn) { ctx.on(window, 'themechange', fn); },

    /** Re-run when the card is resized. */
    onResize(node, fn) {
      if (!('ResizeObserver' in window)) return;
      const ro = new ResizeObserver(fn);
      ro.observe(node);
      cleanups.push(() => ro.disconnect());
    },

    onCleanup(fn) { cleanups.push(fn); },

    destroy() {
      while (cleanups.length) {
        try { cleanups.pop()(); } catch (err) { console.warn(`[${def.id}] cleanup failed`, err); }
      }
    },
  };
  return ctx;
}

/* ── Card chrome ────────────────────────────────────────────────────────── */
function buildCard(def) {
  const card = el('article', {
    class: 'card',
    'data-id': def.id,
    'data-size': def.size,
    'data-category': def.category,
  });

  const head = el('div', { class: 'card__head' }, [
    el('span', { class: 'card__icon', html: def.icon || icon('<circle cx="12" cy="12" r="8"/>') }),
    el('h2', { class: 'card__title', text: def.name, title: def.description || def.name }),
  ]);

  const tools = el('div', { class: 'card__tools' }, [
    el('button', {
      class: 'card__tool', title: 'Hide widget', 'aria-label': `Hide ${def.name}`,
      html: ICONS.hide,
      onclick: () => hideWidget(def.id),
    }),
    el('button', {
      class: 'card__tool handle', title: 'Drag to rearrange', 'aria-label': `Move ${def.name}`,
      html: ICONS.handle,
    }),
  ]);
  head.append(tools);

  const body = el('div', { class: 'card__body' });
  card.append(head, body);

  const ctx = makeContext(def);

  if ('IntersectionObserver' in window) {
    const io = new IntersectionObserver(
      ([entry]) => { ctx.visible = entry.isIntersecting; },
      { rootMargin: '160px' }
    );
    // Observe only once the card is actually in the document — observing a
    // detached node reports "not intersecting" and never corrects itself.
    const raf = requestAnimationFrame(() => io.observe(card));
    ctx.onCleanup(() => { cancelAnimationFrame(raf); io.disconnect(); });
  }

  try {
    const teardown = def.mount(body, ctx);
    if (typeof teardown === 'function') ctx.onCleanup(teardown);
  } catch (err) {
    console.error(`[${def.id}] failed to mount`, err);
    body.append(el('div', { class: 'notice', text: 'This widget failed to load.' }));
  }

  live.set(def.id, { card, ctx });
  enableDrag(card, tools.querySelector('.handle'));
  return card;
}

/* ── Drag to rearrange ──────────────────────────────────────────────────── */
let dragId = null;

function enableDrag(card, handle) {
  handle.addEventListener('pointerdown', () => { card.draggable = true; });
  handle.addEventListener('pointerup',   () => { card.draggable = false; });

  card.addEventListener('dragstart', (e) => {
    dragId = card.dataset.id;
    card.classList.add('is-dragging');
    e.dataTransfer.effectAllowed = 'move';
    e.dataTransfer.setData('text/plain', dragId);
  });

  card.addEventListener('dragend', () => {
    dragId = null;
    card.draggable = false;
    card.classList.remove('is-dragging');
    $$('.card.is-over').forEach((c) => c.classList.remove('is-over'));
    persistOrder();
  });

  card.addEventListener('dragover', (e) => {
    if (!dragId || dragId === card.dataset.id) return;
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
    card.classList.add('is-over');

    const dragged = board.querySelector(`.card[data-id="${dragId}"]`);
    if (!dragged) return;
    const rect = card.getBoundingClientRect();
    const after = (e.clientY - rect.top) / rect.height > 0.5;
    card.parentNode.insertBefore(dragged, after ? card.nextSibling : card);
  });

  card.addEventListener('dragleave', () => card.classList.remove('is-over'));
  card.addEventListener('drop', (e) => {
    e.preventDefault();
    card.classList.remove('is-over');
    persistOrder();
  });
}

function persistOrder() {
  const visible = $$('.card', board).map((c) => c.dataset.id);
  // Keep ids that are currently filtered out, in their previous relative order.
  const rest = state.order.filter((id) => !visible.includes(id));
  state.order = [...visible, ...rest];
  store.set('layout.order', state.order);
}

/* ── Sorting, filtering, rendering ──────────────────────────────────────── */
function sorted() {
  const list = allWidgets();
  if (!state.order.length) return list;
  const rank = new Map(state.order.map((id, i) => [id, i]));
  return list.sort((a, b) => (rank.get(a.id) ?? 1e6) - (rank.get(b.id) ?? 1e6));
}

function matches(def) {
  if (state.hidden.has(def.id)) return false;
  if (state.category !== 'All' && def.category !== state.category) return false;
  const q = state.query.trim().toLowerCase();
  if (!q) return true;
  return [def.name, def.category, def.description, ...(def.keywords || [])]
    .filter(Boolean).join(' ').toLowerCase().includes(q);
}

function render() {
  const wanted = sorted().filter(matches);
  const wantedIds = new Set(wanted.map((w) => w.id));

  // Tear down cards that no longer belong — widgets get to stop their timers.
  for (const [id, entry] of live) {
    if (!wantedIds.has(id)) {
      entry.ctx.destroy();
      entry.card.remove();
      live.delete(id);
    }
  }

  const frag = document.createDocumentFragment();
  for (const def of wanted) {
    frag.append(live.get(def.id)?.card ?? buildCard(def));
  }
  board.append(frag);   // re-appending existing nodes just reorders them

  emptyNote.hidden = wanted.length > 0;
  const total = allWidgets().length;
  countNote.textContent = `${wanted.length} of ${total} widgets`
    + (state.hidden.size ? ` · ${state.hidden.size} hidden` : '');
}

function hideWidget(id) {
  state.hidden.add(id);
  store.set('layout.hidden', [...state.hidden]);
  render();
  renderChips();
}

/* ── Category chips ─────────────────────────────────────────────────────── */
function renderChips() {
  const visibleCount = (name) =>
    allWidgets().filter((w) => !state.hidden.has(w.id) && (name === 'All' || w.category === name)).length;

  const groups = [{ name: 'All' }, ...categories()];
  chipsBar.replaceChildren(...groups.map(({ name }) =>
    el('button', {
      class: `chip${state.category === name ? ' is-active' : ''}`,
      onclick: () => {
        state.category = name;
        store.set('ui.category', name);
        renderChips();
        render();
      },
    }, [
      el('span', { text: name }),
      el('span', { class: 'chip__n', text: String(visibleCount(name)) }),
    ])
  ));
}

/* ── Theme + density ────────────────────────────────────────────────────── */
function applyTheme(theme) {
  document.documentElement.dataset.theme = theme;
  store.set('ui.theme', theme);
  window.dispatchEvent(new CustomEvent('themechange', { detail: { theme } }));
}

function applyDensity(density) {
  board.classList.toggle('is-compact', density === 'compact');
  store.set('ui.density', density);
  $$('.seg__btn').forEach((b) => b.classList.toggle('is-active', b.dataset.density === density));
}

/* ── Wire up ────────────────────────────────────────────────────────────── */
function init() {
  const prefersLight = window.matchMedia?.('(prefers-color-scheme: light)').matches;
  applyTheme(store.get('ui.theme', prefersLight ? 'light' : 'dark'));
  applyDensity(store.get('ui.density', 'comfortable'));

  $('#theme-toggle').addEventListener('click', () =>
    applyTheme(document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark'));

  $$('.seg__btn').forEach((btn) =>
    btn.addEventListener('click', () => applyDensity(btn.dataset.density)));

  $('#reset-layout').addEventListener('click', () => {
    state.hidden.clear();
    state.order = [];
    state.category = 'All';
    state.query = '';
    searchBox.value = '';
    store.del('layout.hidden');
    store.del('layout.order');
    store.set('ui.category', 'All');
    renderChips();
    render();
  });

  let debounce;
  searchBox.addEventListener('input', () => {
    clearTimeout(debounce);
    debounce = setTimeout(() => { state.query = searchBox.value; render(); }, 110);
  });

  document.addEventListener('keydown', (e) => {
    const typing = /^(INPUT|TEXTAREA|SELECT)$/.test(e.target.tagName) || e.target.isContentEditable;
    if (e.key === '/' && !typing) { e.preventDefault(); searchBox.focus(); searchBox.select(); }
    if (e.key === 'Escape' && document.activeElement === searchBox) {
      searchBox.value = ''; state.query = ''; searchBox.blur(); render();
    }
  });

  renderChips();
  render();
}

init();
