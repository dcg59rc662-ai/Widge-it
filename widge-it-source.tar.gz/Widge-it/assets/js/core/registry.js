/* ── Widget registry ────────────────────────────────────────────────────── */
const widgets = [];

/**
 * A widget definition:
 *   id          unique slug (also its storage namespace)
 *   name        display title
 *   category    grouping used by the filter chips
 *   size        sm | md | tall | wide | lg | xl
 *   icon        inline <svg> markup
 *   mount(root, ctx)  renders into the card body; may return a cleanup fn
 */
export function defineWidget(def) {
  if (!def.id || typeof def.mount !== 'function') {
    throw new Error(`Invalid widget definition: ${JSON.stringify(def?.id)}`);
  }
  widgets.push({ size: 'md', category: 'General', ...def });
  return def;
}

export const allWidgets = () => widgets.slice();

export const categories = () => {
  const counts = new Map();
  for (const w of widgets) counts.set(w.category, (counts.get(w.category) ?? 0) + 1);
  return [...counts.entries()].map(([name, count]) => ({ name, count }));
};
