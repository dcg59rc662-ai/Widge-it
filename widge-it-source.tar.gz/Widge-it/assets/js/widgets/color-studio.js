import { defineWidget } from '../core/registry.js';
import { el, icon, copy, flash, hexToRgb, rgbToHex, rgbToHsl, hslToRgb, luminance } from '../core/util.js';

/** WCAG contrast ratio between two rgb triples. */
function contrast(rgb1, rgb2) {
  const lum = (rgb) => {
    const [r, g, b] = rgb.map((v) => {
      const s = v / 255;
      return s <= 0.03928 ? s / 12.92 : ((s + 0.055) / 1.055) ** 2.4;
    });
    return 0.2126 * r + 0.7152 * g + 0.0722 * b;
  };
  const [a, b] = [lum(rgb1), lum(rgb2)].sort((x, y) => y - x);
  return (a + 0.05) / (b + 0.05);
}

export default defineWidget({
  id: 'color-studio',
  name: 'Colour Studio',
  category: 'Tools',
  size: 'lg',
  description: 'Pick a colour, generate harmonies and check contrast. Click a swatch to copy.',
  keywords: ['color', 'palette', 'hex', 'hsl', 'contrast', 'design'],
  icon: icon('<circle cx="13.5" cy="6.5" r="1.2"/><circle cx="17.5" cy="10.5" r="1.2"/><circle cx="8.5" cy="7.5" r="1.2"/><circle cx="6.5" cy="12.5" r="1.2"/><path d="M12 2a10 10 0 1 0 0 20c.9 0 1.6-.7 1.6-1.6 0-.4-.2-.8-.5-1.1-.3-.3-.4-.7-.4-1 0-.9.7-1.6 1.6-1.6H16a6 6 0 0 0 6-6c0-4.7-4.5-8.7-10-8.7Z"/>'),

  mount(root, ctx) {
    let hex = ctx.store.get('hex', '#6d8bff');

    const picker = el('input', { type: 'color', value: hex, style: { width: '44px', height: '44px', border: 'none', background: 'none', padding: '0', cursor: 'pointer', borderRadius: '10px' }, 'aria-label': 'Pick colour' });
    const hexInput = el('input', { class: 'field mono grow', value: hex, 'aria-label': 'Hex value', maxlength: '7' });
    const randomBtn = el('button', { class: 'btn btn--icon', title: 'Random colour', html: icon('<path d="M3 7h4l10 10h4M3 17h4l3-3M14 7h3M18 4l3 3-3 3M18 14l3 3-3 3"/>') });

    const readout = el('div', { class: 'row', style: { gap: '10px', flexWrap: 'wrap', margin: '10px 0' } });
    const harmonyWrap = el('div', { class: 'col fill', style: { gap: '10px', overflowY: 'auto' } });
    const note = el('span', { class: 'flash tiny' });

    root.append(
      el('div', { class: 'row' }, [picker, hexInput, randomBtn]),
      readout,
      harmonyWrap,
      el('div', { class: 'row row--between', style: { marginTop: '8px' } }, [
        el('span', { class: 'tiny dim', text: 'Click any swatch to copy its hex' }), note,
      ])
    );

    const swatch = (value, label) => el('button', {
      title: `Copy ${value}`,
      style: {
        flex: '1 1 0', minWidth: '0', height: '34px', borderRadius: '8px',
        background: value, border: '1px solid var(--line)',
        display: 'grid', placeItems: 'center',
        fontSize: '9.5px', fontFamily: 'var(--mono)', fontWeight: '600',
        color: luminance(...hexToRgb(value)) > 0.55 ? '#0b0d12' : '#fff',
      },
      text: label ?? '',
      onclick: async () => flash(note, (await copy(value)) ? `${value} copied` : 'Copy failed'),
    });

    function harmonyRow(title, colors) {
      return el('div', {}, [
        el('div', { class: 'tiny dim', style: { marginBottom: '4px' } }, title),
        el('div', { class: 'row', style: { gap: '4px' } }, colors.map((c) => swatch(c))),
      ]);
    }

    function render() {
      const rgb = hexToRgb(hex);
      const [h, s, l] = rgbToHsl(...rgb);
      const at = (hh, ss = s, ll = l) => rgbToHex(...hslToRgb(hh, ss, ll));

      const onWhite = contrast(rgb, [255, 255, 255]);
      const onBlack = contrast(rgb, [0, 0, 0]);
      const grade = (r) => (r >= 7 ? 'AAA' : r >= 4.5 ? 'AA' : r >= 3 ? 'AA-lg' : 'Fail');

      readout.replaceChildren(
        el('div', {}, [
          el('div', { class: 'tiny dim', text: 'RGB' }),
          el('div', { class: 'mono small', text: rgb.join(', ') }),
        ]),
        el('div', {}, [
          el('div', { class: 'tiny dim', text: 'HSL' }),
          el('div', { class: 'mono small', text: `${h}° ${s}% ${l}%` }),
        ]),
        el('div', {}, [
          el('div', { class: 'tiny dim', text: 'On white' }),
          el('div', { class: 'mono small', text: `${onWhite.toFixed(2)} · ${grade(onWhite)}` }),
        ]),
        el('div', {}, [
          el('div', { class: 'tiny dim', text: 'On black' }),
          el('div', { class: 'mono small', text: `${onBlack.toFixed(2)} · ${grade(onBlack)}` }),
        ]),
      );

      harmonyWrap.replaceChildren(
        harmonyRow('Shades', [92, 76, 60, 44, 28, 14].map((ll) => at(h, s, ll))),
        harmonyRow('Analogous', [-60, -30, 0, 30, 60].map((d) => at(h + d))),
        harmonyRow('Triadic & complement', [h, h + 120, h + 240, h + 180].map((hh) => at(hh))),
      );
    }

    function setHex(value) {
      if (!/^#?[0-9a-f]{6}$/i.test(value.trim())) return;
      hex = value.trim().startsWith('#') ? value.trim().toLowerCase() : `#${value.trim().toLowerCase()}`;
      picker.value = hex;
      hexInput.value = hex;
      ctx.store.set('hex', hex);
      render();
    }

    picker.addEventListener('input', () => setHex(picker.value));
    hexInput.addEventListener('input', () => setHex(hexInput.value));
    randomBtn.addEventListener('click', () =>
      setHex(rgbToHex(...hslToRgb(Math.random() * 360, 55 + Math.random() * 35, 40 + Math.random() * 25))));

    render();
  },
});
