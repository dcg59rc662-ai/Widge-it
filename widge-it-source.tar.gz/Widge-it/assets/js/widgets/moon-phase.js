import { defineWidget } from '../core/registry.js';
import { el, fitCanvas, cssVar, icon } from '../core/util.js';
import { moonPhase } from '../lib/astro.js';

const days = (n) => `${n.toFixed(1)} day${n >= 1.95 || n < 1.05 ? 's' : ''}`;

export default defineWidget({
  id: 'moon-phase',
  name: 'Moon Phase',
  category: 'Time',
  size: 'md',
  description: 'Current lunar phase, illumination and days to the next full moon.',
  keywords: ['lunar', 'night', 'full moon', 'astronomy'],
  icon: icon('<path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8Z"/>'),

  mount(root, ctx) {
    const canvas = el('canvas');
    const wrap = el('div', { class: 'canvas-wrap' }, canvas);

    const name = el('div', { class: 'small', style: { fontWeight: '600' } });
    const illum = el('div', { class: 'tiny dim' });
    const nextFull = el('div', { class: 'kv' }, [
      el('span', { class: 'kv__k', text: 'Next full' }), el('span', { class: 'kv__v' }),
    ]);
    const nextNew = el('div', { class: 'kv' }, [
      el('span', { class: 'kv__k', text: 'Next new' }), el('span', { class: 'kv__v' }),
    ]);

    root.append(
      wrap,
      el('div', { style: { paddingTop: '8px' } }, [
        el('div', { class: 'row row--between' }, [
          el('div', {}, [name, illum]),
          el('span', { class: 'pill pill--accent', 'data-ref': 'dir' }),
        ]),
        nextFull, nextNew,
      ])
    );

    const dir = root.querySelector('[data-ref="dir"]');
    const c2d = canvas.getContext('2d');

    function draw() {
      const m = moonPhase();

      name.textContent = m.name;
      illum.textContent = `${Math.round(m.illum * 100)}% illuminated · age ${m.age.toFixed(1)}d`;
      dir.textContent = m.waxing ? 'Waxing' : 'Waning';
      nextFull.lastChild.textContent = days(m.toFull);
      nextNew.lastChild.textContent = days(m.toNew);

      const { w, h } = fitCanvas(canvas, c2d);
      const r = Math.min(w, h) / 2 - 4;
      if (r <= 0) return;

      // Fixed lunar palette: the moon is the same colour in both themes.
      const lit = '#e8e6df';
      const dark = '#171a24';
      const line = cssVar('--line-strong', 'rgba(255,255,255,.2)');

      c2d.clearRect(0, 0, w, h);
      c2d.save();
      c2d.translate(w / 2, h / 2);

      // Night sky behind the disc, plus a halo that brightens with illumination
      c2d.beginPath(); c2d.arc(0, 0, r + 6, 0, Math.PI * 2);
      c2d.fillStyle = dark; c2d.globalAlpha = 0.5; c2d.fill();
      c2d.globalAlpha = 1;

      c2d.beginPath(); c2d.arc(0, 0, r + 3, 0, Math.PI * 2);
      c2d.fillStyle = lit; c2d.globalAlpha = 0.08 + m.illum * 0.14; c2d.fill();
      c2d.globalAlpha = 1;

      // Unlit disc
      c2d.beginPath(); c2d.arc(0, 0, r, 0, Math.PI * 2);
      c2d.fillStyle = dark; c2d.fill();
      c2d.strokeStyle = line; c2d.lineWidth = 1; c2d.stroke();

      // Lit portion: a half disc plus the terminator ellipse
      const k = Math.cos(2 * Math.PI * m.phase);   // +1 new, -1 full
      c2d.save();
      c2d.beginPath(); c2d.arc(0, 0, r, 0, Math.PI * 2); c2d.clip();

      c2d.fillStyle = lit;
      c2d.beginPath();
      // Lit half: right side while waxing, left side while waning
      c2d.arc(0, 0, r, -Math.PI / 2, Math.PI / 2, !m.waxing);
      c2d.closePath();
      c2d.fill();

      // Terminator: an ellipse that adds to or carves out of the lit half
      c2d.beginPath();
      c2d.ellipse(0, 0, Math.abs(k) * r, r, 0, 0, Math.PI * 2);
      c2d.fillStyle = (m.waxing ? k > 0 : k < 0) ? dark : lit;
      c2d.fill();
      c2d.restore();

      // Subtle maria so a full moon doesn't read as a flat white circle
      c2d.save();
      c2d.beginPath(); c2d.arc(0, 0, r, 0, Math.PI * 2); c2d.clip();
      c2d.globalAlpha = 0.07;
      c2d.fillStyle = '#000';
      for (const [x, y, rad] of [[-.3, -.25, .22], [.18, -.4, .14], [.05, .3, .3], [-.45, .35, .16], [.42, .18, .12]]) {
        c2d.beginPath(); c2d.arc(x * r, y * r, rad * r, 0, Math.PI * 2); c2d.fill();
      }
      c2d.restore();
      c2d.restore();
    }

    ctx.every(60000, draw);
    ctx.next(draw);              // first paint, once layout has a real size
    ctx.onTheme(draw);
    ctx.onResize(wrap, draw);
  },
});
