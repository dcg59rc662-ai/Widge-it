import { defineWidget } from '../core/registry.js';
import { el, fitCanvas, cssVar, icon, clamp } from '../core/util.js';

const CARDINALS = ['N', 'NE', 'E', 'SE', 'S', 'SW', 'W', 'NW'];
const cardinalOf = (deg) => CARDINALS[Math.round(((deg % 360) + 360) % 360 / 45) % 8];

/** Shortest signed angular distance from a to b, in degrees. */
const angleDelta = (a, b) => ((((b - a) % 360) + 540) % 360) - 180;

export default defineWidget({
  id: 'compass',
  name: 'Compass',
  category: 'Sensors',
  size: 'tall',
  description: 'Magnetic heading from device orientation, with a draggable fallback.',
  keywords: ['heading', 'north', 'bearing', 'navigation', 'direction'],
  icon: icon('<circle cx="12" cy="12" r="9"/><path d="m15.2 8.8-2 4.4-4.4 2 2-4.4 4.4-2Z"/>'),

  mount(root, ctx) {
    const canvas = el('canvas');
    const wrap = el('div', { class: 'canvas-wrap', style: { cursor: 'grab', touchAction: 'none' } }, canvas);

    const heading = el('div', { class: 'metric__value', text: '0°' });
    const cardinal = el('div', { class: 'metric__label', text: 'North' });
    const source = el('span', { class: 'pill', text: 'Manual' });
    const enableBtn = el('button', { class: 'btn btn--sm', text: 'Use sensor' });

    const readout = el('div', { class: 'row row--between', style: { paddingTop: '10px' } }, [
      el('div', {}, [heading, cardinal]),
      el('div', { class: 'col', style: { alignItems: 'flex-end', gap: '6px' } }, [source, enableBtn]),
    ]);

    root.append(wrap, readout);

    const c2d = canvas.getContext('2d');
    let target = 0;     // where the needle wants to point
    let shown = 0;      // smoothed value actually drawn
    let sensor = false;

    /* ── Sensor ── */
    const onOrientation = (e) => {
      const deg = e.webkitCompassHeading ?? (e.alpha != null ? 360 - e.alpha : null);
      if (deg == null || Number.isNaN(deg)) return;
      target = ((deg % 360) + 360) % 360;
      if (!sensor) {
        sensor = true;
        source.textContent = e.absolute || e.webkitCompassHeading != null ? 'Magnetic' : 'Relative';
        source.className = 'pill pill--ok';
        enableBtn.remove();
        wrap.style.cursor = 'default';
      }
    };

    function listen() {
      ctx.on(window, 'deviceorientationabsolute', onOrientation);
      ctx.on(window, 'deviceorientation', onOrientation);
    }

    enableBtn.addEventListener('click', async () => {
      const req = window.DeviceOrientationEvent?.requestPermission;
      if (typeof req === 'function') {
        try {
          if (await req() !== 'granted') { source.textContent = 'Denied'; return; }
        } catch { /* ignore — fall through to plain listening */ }
      }
      listen();
      enableBtn.textContent = 'Listening…';
    });

    // Passive attempt: works on most Android/desktop browsers without a prompt.
    if (typeof window.DeviceOrientationEvent?.requestPermission !== 'function') listen();

    /* ── Drag fallback ── */
    let dragging = false, lastAngle = 0;
    const angleFrom = (e) => {
      const r = canvas.getBoundingClientRect();
      return Math.atan2(e.clientY - (r.top + r.height / 2), e.clientX - (r.left + r.width / 2)) * 180 / Math.PI;
    };
    ctx.on(wrap, 'pointerdown', (e) => {
      if (sensor) return;
      dragging = true; lastAngle = angleFrom(e);
      wrap.setPointerCapture(e.pointerId);
      wrap.style.cursor = 'grabbing';
    });
    ctx.on(wrap, 'pointermove', (e) => {
      if (!dragging) return;
      const a = angleFrom(e);
      target = ((target - (a - lastAngle)) % 360 + 360) % 360;
      lastAngle = a;
    });
    const stop = () => { dragging = false; wrap.style.cursor = sensor ? 'default' : 'grab'; };
    ctx.on(wrap, 'pointerup', stop);
    ctx.on(wrap, 'pointercancel', stop);

    /* ── Draw ── */
    function draw() {
      shown += angleDelta(shown, target) * 0.18;   // critically-damped enough to feel solid
      shown = ((shown % 360) + 360) % 360;

      const { w, h } = fitCanvas(canvas, c2d);
      const r = Math.min(w, h) / 2 - 2;
      if (r <= 0) return;

      const text = cssVar('--text', '#fff');
      const dim = cssVar('--text-3', '#888');
      const accent = cssVar('--accent', '#6d8bff');
      const danger = cssVar('--danger', '#ff6b81');
      const line = cssVar('--line', 'rgba(255,255,255,.1)');

      c2d.clearRect(0, 0, w, h);
      c2d.save();
      c2d.translate(w / 2, h / 2);

      // Fixed bezel + lubber line
      c2d.beginPath(); c2d.arc(0, 0, r, 0, Math.PI * 2);
      c2d.strokeStyle = line; c2d.lineWidth = 1; c2d.stroke();

      c2d.beginPath();
      c2d.moveTo(0, -r - 1); c2d.lineTo(-5, -r + 9); c2d.lineTo(5, -r + 9); c2d.closePath();
      c2d.fillStyle = accent; c2d.fill();

      // Rotating rose
      c2d.rotate((-shown * Math.PI) / 180);

      for (let deg = 0; deg < 360; deg += 5) {
        const major = deg % 45 === 0;
        const mid = deg % 15 === 0;
        c2d.save();
        c2d.rotate((deg * Math.PI) / 180);
        c2d.beginPath();
        c2d.moveTo(0, -r + 8);
        c2d.lineTo(0, -r + (major ? 20 : mid ? 14 : 11));
        c2d.strokeStyle = major ? text : dim;
        c2d.globalAlpha = major ? 0.9 : mid ? 0.45 : 0.22;
        c2d.lineWidth = major ? 2 : 1;
        c2d.stroke();
        c2d.restore();
      }

      // Cardinal letters
      c2d.textAlign = 'center';
      c2d.textBaseline = 'middle';
      CARDINALS.forEach((label, i) => {
        const a = (i * 45 * Math.PI) / 180;
        const rad = r - 32;
        const primary = i % 2 === 0;
        c2d.save();
        c2d.translate(Math.sin(a) * rad, -Math.cos(a) * rad);
        c2d.rotate((shown * Math.PI) / 180);   // keep glyphs upright
        c2d.fillStyle = label === 'N' ? danger : primary ? text : dim;
        c2d.font = `${primary ? 700 : 500} ${primary ? 13 : 10}px ${cssVar('--font', 'sans-serif')}`;
        c2d.globalAlpha = primary ? 1 : 0.6;
        c2d.fillText(label, 0, 0);
        c2d.restore();
      });

      // Needle
      const needle = (len, width, color, dir) => {
        c2d.save();
        c2d.beginPath();
        c2d.moveTo(0, -len * dir);
        c2d.lineTo(-width, 0);
        c2d.lineTo(width, 0);
        c2d.closePath();
        c2d.fillStyle = color;
        c2d.fill();
        c2d.restore();
      };
      needle(r - 46, 6, danger, 1);
      needle(r - 46, 6, cssVar('--text-2', '#999'), -1);

      c2d.beginPath(); c2d.arc(0, 0, 4, 0, Math.PI * 2);
      c2d.fillStyle = cssVar('--card-solid', '#111');
      c2d.fill();
      c2d.strokeStyle = text; c2d.globalAlpha = .6; c2d.lineWidth = 1.5; c2d.stroke();

      c2d.restore();

      heading.textContent = `${Math.round(shown)}°`;
      cardinal.textContent = cardinalOf(shown);
    }

    ctx.frame(draw);
    ctx.onTheme(draw);
  },
});
