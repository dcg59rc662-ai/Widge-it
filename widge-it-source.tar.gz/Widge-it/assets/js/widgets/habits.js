import { defineWidget } from '../core/registry.js';
import { el, icon } from '../core/util.js';

const WEEKS = 18;
const key = (d) => d.toISOString().slice(0, 10);

export default defineWidget({
  id: 'habits',
  name: 'Habit Streak',
  category: 'Productivity',
  size: 'lg',
  description: 'A contribution-style grid — click any day to mark it done.',
  keywords: ['streak', 'heatmap', 'consistency', 'tracker', 'daily'],
  icon: icon('<rect x="3" y="3" width="7" height="7" rx="2"/><rect x="14" y="3" width="7" height="7" rx="2"/><rect x="3" y="14" width="7" height="7" rx="2"/><rect x="14" y="14" width="7" height="7" rx="2"/>'),

  mount(root, ctx) {
    let done = new Set(ctx.store.get('done', []));
    let name = ctx.store.get('name', 'Daily practice');

    const title = el('input', {
      class: 'field', value: name,
      style: { border: 'none', background: 'transparent', padding: '0', fontWeight: '600', fontSize: '13px' },
      'aria-label': 'Habit name',
    });

    const streakPill = el('span', { class: 'pill pill--ok' });
    const head = el('div', { class: 'row row--between', style: { marginBottom: '10px' } }, [title, streakPill]);

    const grid = el('div', {
      class: 'fill',
      style: {
        display: 'grid',
        gridTemplateRows: 'repeat(7, auto)',   // auto rows + square cells keeps the aspect honest
        gridAutoFlow: 'column',
        gridAutoColumns: '1fr',
        gap: '3px',
        alignContent: 'center',
        justifyContent: 'stretch',
      },
    });

    const legend = el('div', { class: 'row row--between', style: { marginTop: '10px' } }, [
      el('span', { class: 'tiny dim', 'data-ref': 'total' }),
      el('span', { class: 'tiny dim', text: 'Click a square to toggle' }),
    ]);

    root.append(head, grid, legend);
    const totalOut = legend.querySelector('[data-ref="total"]');

    title.addEventListener('input', () => { name = title.value; ctx.store.set('name', name); });

    const save = () => { ctx.store.set('done', [...done]); render(); };

    function currentStreak() {
      let n = 0;
      const cursor = new Date();
      // Today not being done yet shouldn't break yesterday's streak.
      if (!done.has(key(cursor))) cursor.setDate(cursor.getDate() - 1);
      while (done.has(key(cursor))) { n++; cursor.setDate(cursor.getDate() - 1); }
      return n;
    }

    function render() {
      grid.replaceChildren();

      const today = new Date();
      today.setHours(0, 0, 0, 0);
      const start = new Date(today);
      start.setDate(start.getDate() - (WEEKS * 7 - 1));
      start.setDate(start.getDate() - ((start.getDay() + 6) % 7));   // align to Monday

      for (let d = new Date(start); d <= today; d.setDate(d.getDate() + 1)) {
        const day = new Date(d);
        const k = key(day);
        const isDone = done.has(k);
        const isToday = k === key(today);

        grid.append(el('button', {
          title: `${day.toLocaleDateString(undefined, { weekday: 'short', day: 'numeric', month: 'short' })}${isDone ? ' · done' : ''}`,
          'aria-label': k,
          style: {
            aspectRatio: '1',
            width: '100%',
            minWidth: '0',
            borderRadius: '3px',
            background: isDone ? 'var(--accent)' : 'var(--track)',
            border: isToday ? '1.5px solid var(--text-2)' : '1px solid transparent',
            opacity: isDone ? '1' : '.85',
            transition: 'background 160ms, transform 160ms',
          },
          onclick: () => { isDone ? done.delete(k) : done.add(k); save(); },
        }));
      }

      const streak = currentStreak();
      streakPill.textContent = `${streak} day streak`;
      streakPill.className = `pill ${streak > 0 ? 'pill--ok' : ''}`;
      totalOut.textContent = `${done.size} day${done.size === 1 ? '' : 's'} logged`;
    }

    render();
  },
});
