import { defineWidget } from '../core/registry.js';
import { el, icon } from '../core/util.js';

const ZONES = [
  { label: 'San Francisco', tz: 'America/Los_Angeles' },
  { label: 'New York',      tz: 'America/New_York' },
  { label: 'London',        tz: 'Europe/London' },
  { label: 'Berlin',        tz: 'Europe/Berlin' },
  { label: 'Dubai',         tz: 'Asia/Dubai' },
  { label: 'Singapore',     tz: 'Asia/Singapore' },
  { label: 'Tokyo',         tz: 'Asia/Tokyo' },
  { label: 'Sydney',        tz: 'Australia/Sydney' },
];

const hourIn = (tz, date) =>
  Number(new Intl.DateTimeFormat('en-GB', { timeZone: tz, hour: 'numeric', hour12: false }).format(date));

/** A tiny day/night bar for the 24h cycle. */
const phaseOf = (h) =>
  h >= 6 && h < 9   ? { label: 'Dawn',  cls: 'pill--warn' }
  : h >= 9 && h < 17 ? { label: 'Day',   cls: 'pill--ok' }
  : h >= 17 && h < 21 ? { label: 'Dusk',  cls: 'pill--warn' }
  : { label: 'Night', cls: '' };

export default defineWidget({
  id: 'clock-world',
  name: 'World Clock',
  category: 'Time',
  size: 'lg',
  description: 'Live time across eight major financial hubs.',
  keywords: ['timezone', 'utc', 'travel', 'meeting'],
  icon: icon('<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c2.6 2.8 2.6 15.2 0 18-2.6-2.8-2.6-15.2 0-18Z"/>'),

  mount(root, ctx) {
    const local = Intl.DateTimeFormat().resolvedOptions().timeZone;
    const head = el('div', { class: 'row row--between', style: { marginBottom: '8px' } }, [
      el('span', { class: 'tiny dim', text: `Local · ${local}` }),
      el('span', { class: 'pill pill--accent', 'data-ref': 'utc' }),
    ]);

    const grid = el('div', {
      style: { display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(150px, 1fr))', gap: '6px 14px', overflowY: 'auto' },
      class: 'fill',
    });

    const rows = ZONES.map(({ label, tz }) => {
      const time = el('span', { class: 'mono', style: { fontSize: '15px', fontWeight: '600' } });
      const badge = el('span', { class: 'pill' });
      const day = el('span', { class: 'tiny dim' });
      const row = el('div', {
        style: { display: 'flex', alignItems: 'center', gap: '8px', padding: '5px 0', borderBottom: '1px solid var(--line)' },
      }, [
        el('div', { class: 'grow' }, [
          el('div', { class: 'small', text: label, style: { fontWeight: '550' } }),
          day,
        ]),
        el('div', { style: { textAlign: 'right' } }, [time, el('div', {}, badge)]),
      ]);
      grid.append(row);
      return { tz, time, badge, day };
    });

    root.append(head, grid);
    const utcOut = head.querySelector('[data-ref="utc"]');

    ctx.every(1000, () => {
      const now = new Date();
      utcOut.textContent = 'UTC ' + now.toISOString().slice(11, 19);

      for (const { tz, time, badge, day } of rows) {
        time.textContent = now.toLocaleTimeString(undefined, {
          timeZone: tz, hour: '2-digit', minute: '2-digit', hour12: false,
        });
        const phase = phaseOf(hourIn(tz, now));
        badge.textContent = phase.label;
        badge.className = `pill ${phase.cls}`;
        day.textContent = now.toLocaleDateString(undefined, { timeZone: tz, weekday: 'short', day: 'numeric', month: 'short' });
      }
    });
  },
});
