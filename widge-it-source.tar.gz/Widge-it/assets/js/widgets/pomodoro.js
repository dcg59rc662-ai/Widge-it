import { defineWidget } from '../core/registry.js';
import { el, icon, hms, clamp } from '../core/util.js';

const MODES = {
  focus: { label: 'Focus', minutes: 25, color: 'var(--accent)' },
  short: { label: 'Short break', minutes: 5, color: 'var(--ok)' },
  long:  { label: 'Long break', minutes: 15, color: 'var(--accent-3)' },
};

/** Short chime, no asset required. */
function chime() {
  try {
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return;
    const ac = new AC();
    const gain = ac.createGain();
    gain.connect(ac.destination);
    gain.gain.setValueAtTime(0.0001, ac.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.25, ac.currentTime + 0.02);
    gain.gain.exponentialRampToValueAtTime(0.0001, ac.currentTime + 1.1);
    [880, 1320].forEach((f, i) => {
      const osc = ac.createOscillator();
      osc.type = 'sine';
      osc.frequency.value = f;
      osc.connect(gain);
      osc.start(ac.currentTime + i * 0.12);
      osc.stop(ac.currentTime + 1.2);
    });
    setTimeout(() => ac.close(), 1500);
  } catch { /* audio blocked — silent is fine */ }
}

export default defineWidget({
  id: 'pomodoro',
  name: 'Focus Timer',
  category: 'Productivity',
  size: 'tall',
  description: 'Pomodoro cycles with a progress ring and completed-session count.',
  keywords: ['pomodoro', 'timer', 'focus', 'break', 'work'],
  icon: icon('<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3.5 2"/>'),

  mount(root, ctx) {
    let mode = 'focus';
    let remaining = MODES.focus.minutes * 60;
    let running = false;
    let endsAt = 0;
    let sessions = ctx.store.get('sessions', 0);

    const tabs = el('div', { class: 'tabs' });
    const tabBtns = Object.entries(MODES).map(([key, m]) =>
      el('button', {
        class: `tabs__btn${key === mode ? ' is-active' : ''}`,
        text: m.label,
        onclick: () => setMode(key),
      })
    );
    tabs.append(...tabBtns);

    const ring = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    ring.setAttribute('viewBox', '0 0 120 120');
    ring.style.cssText = 'width:100%;height:100%;max-height:150px';
    ring.innerHTML = `
      <circle cx="60" cy="60" r="52" fill="none" stroke="var(--track)" stroke-width="7"/>
      <circle id="prog" cx="60" cy="60" r="52" fill="none" stroke="var(--accent)" stroke-width="7"
              stroke-linecap="round" transform="rotate(-90 60 60)"
              stroke-dasharray="326.7" stroke-dashoffset="0" style="transition:stroke-dashoffset .3s linear"/>
      <text id="time" x="60" y="59" text-anchor="middle" dominant-baseline="middle"
            fill="var(--text)" font-family="var(--mono)" font-size="24" font-weight="700" stroke="none">25:00</text>
      <text id="mode" x="60" y="78" text-anchor="middle" dominant-baseline="middle"
            fill="var(--text-3)" font-size="8.5" letter-spacing="1.2" stroke="none">FOCUS</text>`;

    const wrap = el('div', { class: 'canvas-wrap', style: { padding: '10px 0' } }, ring);

    const startBtn = el('button', { class: 'btn btn--primary grow', text: 'Start' });
    const resetBtn = el('button', { class: 'btn btn--icon', html: icon('<path d="M3 12a9 9 0 1 0 2.6-6.4M3 4v5h5"/>'), title: 'Reset' });
    const controls = el('div', { class: 'row', style: { marginTop: '8px' } }, [startBtn, resetBtn]);

    const footer = el('div', { class: 'row row--between', style: { marginTop: '8px' } }, [
      el('span', { class: 'tiny dim', 'data-ref': 'count' }),
      el('button', { class: 'btn btn--sm btn--ghost tiny', text: 'Clear', onclick: () => { sessions = 0; ctx.store.set('sessions', 0); paint(); } }),
    ]);

    root.append(tabs, wrap, controls, footer);

    const progEl = ring.querySelector('#prog');
    const timeEl = ring.querySelector('#time');
    const modeEl = ring.querySelector('#mode');
    const countEl = footer.querySelector('[data-ref="count"]');

    function setMode(key) {
      mode = key;
      running = false;
      remaining = MODES[key].minutes * 60;
      tabBtns.forEach((b, i) => b.classList.toggle('is-active', Object.keys(MODES)[i] === key));
      startBtn.textContent = 'Start';
      paint();
    }

    function paint() {
      const total = MODES[mode].minutes * 60;
      const frac = clamp(remaining / total, 0, 1);
      progEl.setAttribute('stroke-dashoffset', String(326.7 * (1 - frac)));
      progEl.setAttribute('stroke', MODES[mode].color);
      timeEl.textContent = hms(remaining);
      modeEl.textContent = MODES[mode].label.toUpperCase();
      countEl.textContent = `${sessions} focus session${sessions === 1 ? '' : 's'} completed`;
    }

    startBtn.addEventListener('click', () => {
      running = !running;
      if (running) endsAt = Date.now() + remaining * 1000;
      startBtn.textContent = running ? 'Pause' : 'Resume';
    });

    resetBtn.addEventListener('click', () => setMode(mode));

    ctx.every(250, () => {
      if (!running) return;
      remaining = Math.max(0, (endsAt - Date.now()) / 1000);
      if (remaining <= 0) {
        running = false;
        chime();
        if (mode === 'focus') {
          sessions++;
          ctx.store.set('sessions', sessions);
          setMode(sessions % 4 === 0 ? 'long' : 'short');
        } else {
          setMode('focus');
        }
        return;
      }
      paint();
    });

    paint();
  },
});
