import { defineWidget } from '../core/registry.js';
import { el, icon } from '../core/util.js';

const STOP = new Set('the a an and or but of to in on for with at by from is are was were be been it its this that as if then than so we you they he she i not no do does did have has had will would can could'.split(' '));

export default defineWidget({
  id: 'text-stats',
  name: 'Text Analyser',
  category: 'Tools',
  size: 'lg',
  description: 'Counts, reading time, and the words you lean on most.',
  keywords: ['word count', 'characters', 'reading time', 'writing', 'editor'],
  icon: icon('<path d="M4 6h16M4 12h10M4 18h13"/>'),

  mount(root, ctx) {
    const area = el('textarea', {
      class: 'textarea',
      style: { flex: '1 1 auto', minHeight: '60px', fontSize: '13px' },
      placeholder: 'Paste or type text to analyse…',
    });
    area.value = ctx.store.get('text', '');

    const grid = el('div', {
      style: { display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(72px, 1fr))', gap: '8px', padding: '10px 0' },
    });

    const cells = ['Words', 'Characters', 'Sentences', 'Paragraphs', 'Read time'].map((label) => {
      const value = el('div', { class: 'mono', style: { fontSize: '16px', fontWeight: '700' }, text: '0' });
      grid.append(el('div', {}, [value, el('div', { class: 'tiny dim', text: label })]));
      return value;
    });

    const top = el('div', { class: 'row wrap', style: { gap: '5px', minHeight: '22px' } });
    root.append(area, grid, el('div', { class: 'tiny dim', style: { marginBottom: '5px' } }, 'Most used'), top);

    function analyse() {
      const text = area.value;
      const words = text.trim() ? text.trim().split(/\s+/) : [];
      const sentences = text.split(/[.!?]+(?:\s|$)/).filter((s) => s.trim()).length;
      const paragraphs = text.split(/\n{2,}/).filter((p) => p.trim()).length;
      const minutes = words.length / 220;

      cells[0].textContent = words.length.toLocaleString();
      cells[1].textContent = text.length.toLocaleString();
      cells[2].textContent = String(sentences);
      cells[3].textContent = String(paragraphs);
      cells[4].textContent = words.length ? (minutes < 1 ? `${Math.ceil(minutes * 60)}s` : `${Math.ceil(minutes)}m`) : '—';

      const counts = new Map();
      for (const raw of words) {
        const w = raw.toLowerCase().replace(/[^a-z0-9'-]/g, '');
        if (w.length < 3 || STOP.has(w)) continue;
        counts.set(w, (counts.get(w) ?? 0) + 1);
      }
      const ranked = [...counts.entries()].sort((a, b) => b[1] - a[1]).slice(0, 8);
      top.replaceChildren(...(ranked.length
        ? ranked.map(([w, n]) => el('span', { class: 'pill pill--accent', text: `${w} ${n}` }))
        : [el('span', { class: 'tiny dim', text: '—' })]));
    }

    let timer;
    area.addEventListener('input', () => {
      analyse();
      clearTimeout(timer);
      timer = setTimeout(() => ctx.store.set('text', area.value), 500);
    });
    ctx.onCleanup(() => clearTimeout(timer));

    analyse();
  },
});
