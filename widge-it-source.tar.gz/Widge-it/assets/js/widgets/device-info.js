import { defineWidget } from '../core/registry.js';
import { el, icon, fmtBytes } from '../core/util.js';

export default defineWidget({
  id: 'device-info',
  name: 'Device',
  category: 'System',
  size: 'md',
  description: 'What the browser knows about this machine and viewport.',
  keywords: ['screen', 'hardware', 'browser', 'system', 'resolution'],
  icon: icon('<rect x="2" y="4" width="20" height="13" rx="2.5"/><path d="M8 21h8M12 17v4"/>'),

  mount(root, ctx) {
    const list = el('div', { class: 'fill', style: { overflowY: 'auto' } });
    root.append(list);

    const rows = () => {
      const nav = navigator;
      const conn = nav.connection || nav.mozConnection || nav.webkitConnection;
      return [
        ['Viewport', `${window.innerWidth} × ${window.innerHeight}`],
        ['Screen', `${screen.width} × ${screen.height}`],
        ['Pixel ratio', `${(window.devicePixelRatio || 1).toFixed(2)}×`],
        ['Colour depth', `${screen.colorDepth}-bit`],
        ['CPU threads', nav.hardwareConcurrency ? String(nav.hardwareConcurrency) : 'n/a'],
        ['Device memory', nav.deviceMemory ? `${nav.deviceMemory} GB` : 'n/a'],
        ['Platform', nav.userAgentData?.platform || nav.platform || 'n/a'],
        ['Language', nav.language || 'n/a'],
        ['Time zone', Intl.DateTimeFormat().resolvedOptions().timeZone],
        ['Touch points', String(nav.maxTouchPoints ?? 0)],
        ['Connection', conn?.effectiveType ? conn.effectiveType.toUpperCase() : 'n/a'],
        ['JS heap', performance.memory ? fmtBytes(performance.memory.usedJSHeapSize) : 'n/a'],
      ];
    };

    const render = () => {
      list.replaceChildren(...rows().map(([k, v]) =>
        el('div', { class: 'kv' }, [
          el('span', { class: 'kv__k', text: k }),
          el('span', { class: 'kv__v', text: v, title: v }),
        ])));
    };

    ctx.every(2000, render);
    ctx.on(window, 'resize', render);
  },
});
