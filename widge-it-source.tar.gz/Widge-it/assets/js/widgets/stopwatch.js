import { defineWidget } from '../core/registry.js';
import { el, icon, pad2 } from '../core/util.js';

const format = (ms) => {
  const t = Math.max(0, ms);
  const m = Math.floor(t / 60000);
  const s = Math.floor((t % 60000) / 1000);
  const cs = Math.floor((t % 1000) / 10);
  return `${pad2(m)}:${pad2(s)}.${pad2(cs)}`;
};

export default defineWidget({
  id: 'stopwatch',
  name: 'Stopwatch',
  category: 'Time',
  size: 'md',
  description: 'Centisecond timing with lap splits and best/worst markers.',
  keywords: ['timer', 'lap', 'split', 'elapsed', 'sport'],
  icon: icon('<circle cx="12" cy="13" r="8"/><path d="M12 9.5V13M9 2h6M18.5 6.5 20 5"/>'),

  mount(root, ctx) {
    let running = false;
    let startedAt = 0;
    let elapsed = 0;
    let laps = [];

    const display = el('div', {
      class: 'mono',
      style: { fontSize: 'clamp(26px, 10cqw, 38px)', fontWeight: '700', letterSpacing: '-.03em', textAlign: 'center', padding: '6px 0' },
      text: '00:00.00',
    });

    const primary = el('button', { class: 'btn btn--primary grow', text: 'Start' });
    const lapBtn = el('button', { class: 'btn grow', text: 'Lap', disabled: true });
    const list = el('div', { class: 'list fill', style: { marginTop: '8px' } });

    root.append(display, el('div', { class: 'row' }, [primary, lapBtn]), list);

    function renderLaps() {
      if (!laps.length) {
        list.replaceChildren(el('div', { class: 'notice', text: 'No laps recorded' }));
        return;
      }
      const best = Math.min(...laps);
      const worst = Math.max(...laps);
      list.replaceChildren(...laps.map((lap, i) => {
        const tag = laps.length > 2 && lap === best ? 'pill--ok' : laps.length > 2 && lap === worst ? 'pill--danger' : '';
        return el('div', { class: 'list__item' }, [
          el('span', { class: 'tiny dim', style: { width: '28px' }, text: `#${laps.length - i}` }),
          el('span', { class: 'mono grow', style: { fontSize: '12.5px' }, text: format(lap) }),
          tag ? el('span', { class: `pill ${tag}`, text: tag.includes('ok') ? 'best' : 'worst' }) : null,
        ]);
      }).reverse());
    }

    primary.addEventListener('click', () => {
      if (running) {
        elapsed += Date.now() - startedAt;
        running = false;
        primary.textContent = 'Resume';
        lapBtn.textContent = 'Reset';
      } else if (primary.textContent === 'Resume' || primary.textContent === 'Start') {
        startedAt = Date.now();
        running = true;
        primary.textContent = 'Stop';
        lapBtn.textContent = 'Lap';
        lapBtn.disabled = false;
      }
    });

    lapBtn.addEventListener('click', () => {
      if (running) {
        const total = elapsed + (Date.now() - startedAt);
        const previous = laps.reduce((a, b) => a + b, 0);
        laps.push(total - previous);
        renderLaps();
      } else {
        elapsed = 0; laps = []; running = false;
        primary.textContent = 'Start';
        lapBtn.disabled = true;
        display.textContent = '00:00.00';
        renderLaps();
      }
    });

    ctx.frame(() => {
      if (!running) return;
      display.textContent = format(elapsed + (Date.now() - startedAt));
    });

    renderLaps();
  },
});
