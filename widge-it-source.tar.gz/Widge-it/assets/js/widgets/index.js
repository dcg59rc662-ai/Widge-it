/* ── Widget manifest ────────────────────────────────────────────────────────
   Importing a module registers its widget. The order here is the default
   board order — users can drag cards around and the layout persists.
   To add a widget: drop a file in this folder and add one import line.        */

import './compass.js';
import './clock-analog.js';
import './sun-arc.js';
import './pomodoro.js';
import './clock-world.js';
import './moon-phase.js';
import './performance.js';
import './tasks.js';
import './color-studio.js';
import './calculator.js';
import './audio-spectrum.js';
import './level.js';
import './habits.js';
import './notes.js';
import './market.js';
import './year-progress.js';
import './unit-converter.js';
import './battery.js';
import './calendar.js';
import './breathing.js';
import './password.js';
import './countdown.js';
import './stopwatch.js';
import './network.js';
import './metronome.js';
import './gradient-lab.js';
import './text-stats.js';
import './device-info.js';
import './water.js';
import './tip-split.js';
import './dice.js';
import './quote.js';
