import { defineWidget } from '../core/registry.js';
import { el, fitCanvas, cssVar, icon, clamp } from '../core/util.js';

const BARS = 40;

export default defineWidget({
  id: 'audio-spectrum',
  name: 'Audio Spectrum',
  category: 'Sensors',
  size: 'wide',
  description: 'Real-time frequency analysis from the microphone.',
  keywords: ['music', 'microphone', 'visualizer', 'sound', 'eq'],
  icon: icon('<path d="M4 12v3M8 8v11M12 4v16M16 8v11M20 12v3"/>'),

  mount(root, ctx) {
    const canvas = el('canvas', { style: { width: '100%', height: '100%' } });
    const wrap = el('div', { class: 'canvas-wrap fill' }, canvas);

    const startBtn = el('button', { class: 'btn btn--sm btn--primary', text: 'Enable microphone' });
    const levelOut = el('span', { class: 'tiny dim', text: 'Idle' });
    const peakOut = el('span', { class: 'pill' });

    root.append(
      el('div', { class: 'row row--between', style: { marginBottom: '8px' } }, [levelOut, peakOut]),
      wrap,
      el('div', { class: 'row', style: { marginTop: '8px' } }, startBtn)
    );

    const c2d = canvas.getContext('2d');
    let analyser = null;
    let data = null;
    const smooth = new Array(BARS).fill(0);

    startBtn.addEventListener('click', async () => {
      startBtn.textContent = 'Requesting…';
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        const AC = window.AudioContext || window.webkitAudioContext;
        const ac = new AC();
        const src = ac.createMediaStreamSource(stream);
        analyser = ac.createAnalyser();
        analyser.fftSize = 1024;
        analyser.smoothingTimeConstant = 0.75;
        src.connect(analyser);
        data = new Uint8Array(analyser.frequencyBinCount);

        startBtn.textContent = 'Listening';
        startBtn.classList.remove('btn--primary');
        startBtn.disabled = true;

        ctx.onCleanup(() => {
          stream.getTracks().forEach((t) => t.stop());
          ac.close().catch(() => {});
        });
      } catch {
        startBtn.textContent = 'Microphone blocked';
        startBtn.disabled = true;
        levelOut.textContent = 'Permission denied';
      }
    });

    function draw() {
      const { w, h } = fitCanvas(canvas, c2d);
      if (w < 4 || h < 4) return;

      const accent = cssVar('--accent', '#6d8bff');
      const accent2 = cssVar('--accent-2', '#3ddbc0');
      const track = cssVar('--track', 'rgba(255,255,255,.08)');

      c2d.clearRect(0, 0, w, h);

      let peak = 0;
      if (analyser) {
        analyser.getByteFrequencyData(data);
        // Log-ish grouping so bass doesn't swamp the display
        for (let i = 0; i < BARS; i++) {
          const lo = Math.floor((i / BARS) ** 1.7 * data.length);
          const hi = Math.max(lo + 1, Math.floor(((i + 1) / BARS) ** 1.7 * data.length));
          let sum = 0;
          for (let j = lo; j < hi; j++) sum += data[j];
          const value = (sum / (hi - lo)) / 255;
          smooth[i] += (value - smooth[i]) * 0.35;
          peak = Math.max(peak, smooth[i]);
        }
      } else {
        // Gentle idle animation so the card never looks broken
        const t = performance.now() / 700;
        for (let i = 0; i < BARS; i++) {
          smooth[i] += ((0.06 + 0.05 * Math.sin(t + i * 0.4)) - smooth[i]) * 0.1;
        }
      }

      const gap = 2;
      const bw = Math.max(1, (w - gap * (BARS - 1)) / BARS);
      const grad = c2d.createLinearGradient(0, h, 0, 0);
      grad.addColorStop(0, accent);
      grad.addColorStop(1, accent2);

      for (let i = 0; i < BARS; i++) {
        const x = i * (bw + gap);
        const bh = Math.max(2, clamp(smooth[i], 0, 1) * h);

        // A short stub marks each band without filling the card with grey.
        c2d.fillStyle = track;
        c2d.beginPath();
        c2d.roundRect(x, h - 2, bw, 2, 1);
        c2d.fill();

        c2d.fillStyle = grad;
        c2d.beginPath();
        c2d.roundRect(x, h - bh, bw, bh, 2);
        c2d.fill();
      }

      if (analyser) {
        const db = peak > 0 ? 20 * Math.log10(peak) : -60;
        levelOut.textContent = `Peak ${db.toFixed(0)} dB`;
        const [label, cls] = peak > 0.75 ? ['Hot', 'pill--danger'] : peak > 0.25 ? ['Good', 'pill--ok'] : ['Quiet', ''];
        peakOut.textContent = label;
        peakOut.className = `pill ${cls}`;
      } else {
        peakOut.textContent = 'Standby';
        peakOut.className = 'pill';
      }
    }

    ctx.frame(draw);
  },
});
