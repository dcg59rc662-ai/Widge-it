import { defineWidget } from '../core/registry.js';
import { el, fitCanvas, cssVar, icon, fmtBytes, smoothLine, clamp } from '../core/util.js';

const SAMPLES = 90;

export default defineWidget({
  id: 'performance',
  name: 'Render Monitor',
  category: 'System',
  size: 'md',
  description: 'Live frame rate, frame time and JS heap usage.',
  keywords: ['fps', 'performance', 'memory', 'graph', 'monitor'],
  icon: icon('<path d="M3 17l5-6 4 4 5-7 4 5"/><path d="M3 21h18"/>'),

  mount(root, ctx) {
    const fpsOut = el('span', { class: 'metric__value', text: '—' });
    const unit = el('span', { class: 'metric__unit', text: 'fps' });
    const badge = el('span', { class: 'pill' });

    const canvas = el('canvas', { style: { width: '100%', height: '100%' } });
    const graph = el('div', { class: 'canvas-wrap fill', style: { minHeight: '50px' } }, canvas);

    const detail = el('div', { class: 'row row--between', style: { marginTop: '8px' } }, [
      el('span', { class: 'tiny dim', 'data-ref': 'frame' }),
      el('span', { class: 'tiny dim', 'data-ref': 'heap' }),
    ]);

    root.append(
      el('div', { class: 'row row--between', style: { marginBottom: '6px' } }, [
        el('div', { class: 'metric' }, [fpsOut, unit]), badge,
      ]),
      graph, detail
    );

    const frameOut = detail.querySelector('[data-ref="frame"]');
    const heapOut = detail.querySelector('[data-ref="heap"]');
    frameOut.textContent = 'sampling…';
    heapOut.textContent = performance.memory ? '' : 'heap n/a';
    badge.textContent = 'Idle';
    badge.className = 'pill';
    const c2d = canvas.getContext('2d');

    const history = new Array(SAMPLES).fill(60);
    let frames = 0;
    let last = performance.now();
    let worstFrame = 0;
    let prevFrame = last;

    ctx.frame((now) => {
      frames++;
      const delta = now - prevFrame;
      prevFrame = now;
      if (delta > worstFrame) worstFrame = delta;

      if (now - last < 500) return;

      const fps = (frames * 1000) / (now - last);
      frames = 0;
      last = now;

      history.push(fps);
      history.shift();

      fpsOut.textContent = fps.toFixed(0);
      frameOut.textContent = `frame ${(1000 / fps).toFixed(1)} ms · peak ${worstFrame.toFixed(0)} ms`;
      worstFrame = 0;

      heapOut.textContent = performance.memory
        ? `heap ${fmtBytes(performance.memory.usedJSHeapSize)}`
        : 'heap n/a';

      const [label, cls] = fps >= 55 ? ['Smooth', 'pill--ok'] : fps >= 30 ? ['Fair', 'pill--warn'] : ['Janky', 'pill--danger'];
      badge.textContent = label;
      badge.className = `pill ${cls}`;

      draw();
    });

    function draw() {
      const { w, h } = fitCanvas(canvas, c2d);
      if (w < 4 || h < 4) return;

      const accent = cssVar('--accent', '#6d8bff');
      const line = cssVar('--line', 'rgba(255,255,255,.1)');
      const max = 75;

      c2d.clearRect(0, 0, w, h);

      // 30 / 60 fps guides
      for (const guide of [30, 60]) {
        const y = h - (clamp(guide, 0, max) / max) * h;
        c2d.beginPath();
        c2d.moveTo(0, y); c2d.lineTo(w, y);
        c2d.strokeStyle = line; c2d.lineWidth = 1; c2d.setLineDash([2, 4]); c2d.stroke();
        c2d.setLineDash([]);
      }

      const pts = history.map((v, i) => ({
        x: (i / (SAMPLES - 1)) * w,
        y: h - (clamp(v, 0, max) / max) * h,
      }));

      c2d.beginPath();
      smoothLine(c2d, pts);
      c2d.strokeStyle = accent;
      c2d.lineWidth = 1.8;
      c2d.stroke();

      c2d.lineTo(w, h); c2d.lineTo(0, h); c2d.closePath();
      c2d.fillStyle = accent;
      c2d.globalAlpha = 0.13;
      c2d.fill();
      c2d.globalAlpha = 1;
    }

    ctx.next(draw);
    ctx.onTheme(draw);
    ctx.onResize(graph, draw);
  },
});
