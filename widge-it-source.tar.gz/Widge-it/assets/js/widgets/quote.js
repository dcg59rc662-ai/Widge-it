import { defineWidget } from '../core/registry.js';
import { el, icon, copy, flash } from '../core/util.js';

const QUOTES = [
  ['Simplicity is the ultimate sophistication.', 'Leonardo da Vinci'],
  ['Make it work, make it right, make it fast.', 'Kent Beck'],
  ['Perfection is achieved when there is nothing left to take away.', 'Antoine de Saint-Exupéry'],
  ['The details are not the details. They make the design.', 'Charles Eames'],
  ['Any sufficiently advanced technology is indistinguishable from magic.', 'Arthur C. Clarke'],
  ['Premature optimization is the root of all evil.', 'Donald Knuth'],
  ['Design is not just what it looks like. Design is how it works.', 'Steve Jobs'],
  ['Walking on water and developing software from a specification are easy if both are frozen.', 'Edward Berard'],
  ['The best way to predict the future is to invent it.', 'Alan Kay'],
  ['Talk is cheap. Show me the code.', 'Linus Torvalds'],
  ['Programs must be written for people to read, and only incidentally for machines to execute.', 'Harold Abelson'],
  ['There are two ways of constructing a design: make it so simple there are obviously no deficiencies, or so complicated there are no obvious deficiencies.', 'C.A.R. Hoare'],
  ['Good design is as little design as possible.', 'Dieter Rams'],
  ['First, solve the problem. Then, write the code.', 'John Johnson'],
];

export default defineWidget({
  id: 'quote',
  name: 'Daily Quote',
  category: 'Data',
  size: 'md',
  description: 'One line on craft, picked fresh each day.',
  keywords: ['inspiration', 'wisdom', 'design', 'motivation'],
  icon: icon('<path d="M9 7H5.5A2.5 2.5 0 0 0 3 9.5V12a3 3 0 0 0 3 3h1v2H4"/><path d="M19 7h-3.5A2.5 2.5 0 0 0 13 9.5V12a3 3 0 0 0 3 3h1v2h-3"/>'),

  mount(root, ctx) {
    // Same quote all day, a new one tomorrow.
    let index = Math.floor(Date.now() / 86400000) % QUOTES.length;

    const text = el('blockquote', {
      style: { margin: '0', fontSize: '14.5px', lineHeight: '1.55', fontWeight: '450', letterSpacing: '-.005em' },
    });
    const author = el('div', { class: 'tiny dim', style: { marginTop: '10px' } });

    const nextBtn = el('button', { class: 'btn btn--sm btn--ghost', text: 'Another' });
    const copyBtn = el('button', { class: 'btn btn--sm btn--ghost', html: icon('<rect x="9" y="9" width="11" height="11" rx="2"/><path d="M5 15V5a2 2 0 0 1 2-2h8"/>'), title: 'Copy' });
    const note = el('span', { class: 'flash tiny' });

    root.append(
      el('div', { class: 'fill', style: { display: 'flex', flexDirection: 'column', justifyContent: 'center' } }, [text, author]),
      el('div', { class: 'row row--between', style: { marginTop: '8px' } }, [note, el('div', { class: 'row', style: { gap: '4px' } }, [nextBtn, copyBtn])])
    );

    function render() {
      const [q, who] = QUOTES[index];
      text.textContent = `“${q}”`;
      author.textContent = `— ${who}`;
    }

    nextBtn.addEventListener('click', () => {
      index = (index + 1) % QUOTES.length;
      render();
    });

    copyBtn.addEventListener('click', async () => {
      const [q, who] = QUOTES[index];
      flash(note, (await copy(`“${q}” — ${who}`)) ? 'Copied' : 'Copy failed');
    });

    render();
    ctx.every(3600000, render);
  },
});
