import { defineWidget } from '../core/registry.js';
import { el, icon, clamp } from '../core/util.js';

const TIPS = [10, 15, 18, 20, 25];

export default defineWidget({
  id: 'tip-split',
  name: 'Tip & Split',
  category: 'Tools',
  size: 'md',
  description: 'Split a bill evenly, tip included, with rounding per person.',
  keywords: ['bill', 'restaurant', 'money', 'split', 'gratuity'],
  icon: icon('<path d="M12 2v20"/><path d="M17 6.5c0-2-2.2-3-5-3s-5 1-5 3 2 2.8 5 3.4 5 1.5 5 3.6-2.2 3-5 3-5-1-5-3"/>'),

  mount(root, ctx) {
    const state = ctx.store.get('state', { bill: 84, tip: 18, people: 3, round: false });

    const bill = el('input', { class: 'field mono', type: 'number', min: '0', step: '0.01', value: String(state.bill), 'aria-label': 'Bill amount' });

    const tipBtns = el('div', { class: 'row', style: { gap: '4px' } });
    const buttons = TIPS.map((t) =>
      el('button', {
        class: `btn btn--sm grow${t === state.tip ? ' is-on' : ''}`,
        text: `${t}%`,
        onclick: () => { state.tip = t; custom.value = String(t); sync(); },
      }));
    tipBtns.append(...buttons);

    const custom = el('input', { class: 'range grow', type: 'range', min: '0', max: '40', value: String(state.tip), 'aria-label': 'Custom tip' });

    const people = el('input', { class: 'field mono', type: 'number', min: '1', step: '1', value: String(state.people), 'aria-label': 'People' });
    const roundBtn = el('button', { class: `btn btn--sm${state.round ? ' is-on' : ''}`, text: 'Round up' });

    const perPerson = el('div', { class: 'metric__value' });
    const breakdown = el('div', { class: 'tiny dim' });

    root.append(
      el('div', { class: 'row', style: { gap: '8px' } }, [
        el('div', { class: 'grow' }, [el('div', { class: 'tiny dim', text: 'Bill' }), bill]),
        el('div', { style: { width: '78px' } }, [el('div', { class: 'tiny dim', text: 'People' }), people]),
      ]),
      el('div', { class: 'tiny dim', style: { margin: '10px 0 4px' }, 'data-ref': 'tiplabel' }),
      tipBtns,
      custom,
      el('div', { class: 'row row--between', style: { marginTop: 'auto', paddingTop: '10px' } }, [
        el('div', {}, [el('div', { class: 'metric__label', text: 'Each pays' }), perPerson]),
        roundBtn,
      ]),
      breakdown
    );

    const tipLabel = root.querySelector('[data-ref="tiplabel"]');
    const money = (n) => n.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });

    function sync() {
      state.bill = Math.max(0, parseFloat(bill.value) || 0);
      state.people = clamp(parseInt(people.value, 10) || 1, 1, 999);
      state.tip = clamp(Number(custom.value), 0, 100);
      ctx.store.set('state', state);

      buttons.forEach((b, i) => b.classList.toggle('is-on', TIPS[i] === state.tip));
      tipLabel.textContent = `Tip · ${state.tip}%`;

      const tipAmount = state.bill * (state.tip / 100);
      const total = state.bill + tipAmount;
      let share = total / state.people;
      if (state.round) share = Math.ceil(share);

      perPerson.textContent = money(share);
      breakdown.textContent =
        `Total ${money(state.round ? share * state.people : total)} · tip ${money(tipAmount)} · ${state.people} ${state.people === 1 ? 'person' : 'people'}`;
    }

    [bill, people].forEach((n) => n.addEventListener('input', sync));
    custom.addEventListener('input', sync);
    roundBtn.addEventListener('click', () => {
      state.round = !state.round;
      roundBtn.classList.toggle('is-on', state.round);
      sync();
    });

    sync();
  },
});
