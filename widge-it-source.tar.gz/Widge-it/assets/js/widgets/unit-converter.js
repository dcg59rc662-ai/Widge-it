import { defineWidget } from '../core/registry.js';
import { el, icon } from '../core/util.js';

/* Every unit is expressed as a factor to the category's base unit. */
const CATEGORIES = {
  Length: { base: 'm', units: { mm: 0.001, cm: 0.01, m: 1, km: 1000, in: 0.0254, ft: 0.3048, yd: 0.9144, mi: 1609.344, nmi: 1852 } },
  Mass:   { base: 'kg', units: { mg: 1e-6, g: 0.001, kg: 1, t: 1000, oz: 0.0283495, lb: 0.453592, st: 6.35029 } },
  Data:   { base: 'MB', units: { B: 1e-6, KB: 0.001, MB: 1, GB: 1000, TB: 1e6, KiB: 0.001024, MiB: 1.048576, GiB: 1073.74 } },
  Speed:  { base: 'm/s', units: { 'm/s': 1, 'km/h': 0.277778, mph: 0.44704, knot: 0.514444, 'ft/s': 0.3048 } },
  Area:   { base: 'm²', units: { 'mm²': 1e-6, 'cm²': 1e-4, 'm²': 1, 'km²': 1e6, 'ft²': 0.092903, acre: 4046.86, ha: 10000 } },
  Volume: { base: 'L', units: { ml: 0.001, L: 1, 'm³': 1000, tsp: 0.00492892, tbsp: 0.0147868, cup: 0.236588, pint: 0.473176, gal: 3.78541 } },
  Time:   { base: 's', units: { ms: 0.001, s: 1, min: 60, h: 3600, day: 86400, week: 604800, year: 31557600 } },
};

/* Temperature needs offsets, so it converts through Celsius explicitly. */
const TEMPS = {
  '°C': { to: (c) => c, from: (c) => c },
  '°F': { to: (f) => (f - 32) * 5 / 9, from: (c) => c * 9 / 5 + 32 },
  K:    { to: (k) => k - 273.15, from: (c) => c + 273.15 },
};

const trim = (n) => {
  if (!Number.isFinite(n)) return '—';
  const abs = Math.abs(n);
  if (abs !== 0 && (abs >= 1e9 || abs < 1e-4)) return n.toExponential(4);
  return String(Number(n.toFixed(6)));
};

export default defineWidget({
  id: 'unit-converter',
  name: 'Unit Converter',
  category: 'Tools',
  size: 'md',
  description: 'Length, mass, data, speed, area, volume, time and temperature.',
  keywords: ['convert', 'metric', 'imperial', 'measurement', 'units'],
  icon: icon('<path d="M3 7h18M3 17h18"/><path d="M7 4v6M17 14v6"/>'),

  mount(root, ctx) {
    const names = [...Object.keys(CATEGORIES), 'Temperature'];
    let category = ctx.store.get('category', 'Length');
    if (!names.includes(category)) category = 'Length';

    const catSel = el('select', { class: 'select' }, names.map((n) =>
      el('option', { value: n, text: n, selected: n === category })));

    const amount = el('input', { class: 'field mono grow', type: 'number', value: '1', step: 'any', 'aria-label': 'Amount' });
    const fromSel = el('select', { class: 'select', style: { width: '108px' }, 'aria-label': 'From unit' });
    const toSel = el('select', { class: 'select', style: { width: '108px' }, 'aria-label': 'To unit' });
    const result = el('div', {
      class: 'mono',
      style: { fontSize: 'clamp(20px, 7cqw, 27px)', fontWeight: '700', letterSpacing: '-.02em', overflow: 'hidden', textOverflow: 'ellipsis' },
    });
    const note = el('div', { class: 'tiny dim' });

    const swapBtn = el('button', {
      class: 'btn btn--icon', title: 'Swap units',
      html: icon('<path d="M7 4v13M4 14l3 3 3-3M17 20V7M14 10l3-3 3 3"/>'),
    });

    root.append(
      catSel,
      el('div', { class: 'row', style: { marginTop: '8px' } }, [amount, fromSel]),
      el('div', { class: 'row', style: { margin: '8px 0', justifyContent: 'center' } }, swapBtn),
      el('div', { class: 'row' }, [el('div', { class: 'grow' }, [result, note]), toSel])
    );

    function unitList() {
      return category === 'Temperature' ? Object.keys(TEMPS) : Object.keys(CATEGORIES[category].units);
    }

    function fillUnits() {
      const units = unitList();
      for (const [sel, index] of [[fromSel, 0], [toSel, Math.min(1, units.length - 1)]]) {
        const previous = sel.value;
        sel.replaceChildren(...units.map((u) => el('option', { value: u, text: u })));
        sel.value = units.includes(previous) ? previous : units[index];
      }
    }

    function convert() {
      const value = parseFloat(amount.value);
      if (Number.isNaN(value)) { result.textContent = '—'; note.textContent = ''; return; }

      let out;
      if (category === 'Temperature') {
        out = TEMPS[toSel.value].from(TEMPS[fromSel.value].to(value));
      } else {
        const { units } = CATEGORIES[category];
        out = (value * units[fromSel.value]) / units[toSel.value];
      }

      result.textContent = `${trim(out)} ${toSel.value}`;
      note.textContent = `${trim(value)} ${fromSel.value} = ${trim(out)} ${toSel.value}`;
    }

    catSel.addEventListener('change', () => {
      category = catSel.value;
      ctx.store.set('category', category);
      fillUnits();
      convert();
    });

    swapBtn.addEventListener('click', () => {
      [fromSel.value, toSel.value] = [toSel.value, fromSel.value];
      convert();
    });

    [amount, fromSel, toSel].forEach((node) => node.addEventListener('input', convert));

    fillUnits();
    convert();
  },
});
