import { defineWidget } from '../core/registry.js';
import { el, icon } from '../core/util.js';

const DICE = [4, 6, 8, 10, 12, 20];

const roll = (sides) => {
  const buf = new Uint32Array(1);
  crypto.getRandomValues(buf);
  return (buf[0] % sides) + 1;
};

export default defineWidget({
  id: 'dice',
  name: 'Dice Roller',
  category: 'Data',
  size: 'md',
  description: 'Fair polyhedral dice with a running roll history.',
  keywords: ['random', 'rpg', 'd20', 'game', 'chance'],
  icon: icon('<rect x="3" y="3" width="18" height="18" rx="4"/><circle cx="8.5" cy="8.5" r="1.2"/><circle cx="15.5" cy="15.5" r="1.2"/><circle cx="12" cy="12" r="1.2"/>'),

  mount(root, ctx) {
    let sides = ctx.store.get('sides', 20);
    let count = ctx.store.get('count', 1);
    let history = [];

    const total = el('div', {
      class: 'mono',
      style: { fontSize: 'clamp(30px, 11cqw, 44px)', fontWeight: '700', letterSpacing: '-.03em', lineHeight: '1' },
      text: '—',
    });
    const detail = el('div', { class: 'tiny dim', style: { minHeight: '16px' } });

    const sideTabs = el('div', { class: 'tabs', style: { margin: '10px 0 8px' } });
    const sideBtns = DICE.map((d) =>
      el('button', {
        class: `tabs__btn${d === sides ? ' is-active' : ''}`,
        text: `d${d}`,
        onclick: () => {
          sides = d;
          ctx.store.set('sides', d);
          sideBtns.forEach((b, i) => b.classList.toggle('is-active', DICE[i] === d));
        },
      }));
    sideTabs.append(...sideBtns);

    const countInput = el('input', { class: 'field mono', type: 'number', min: '1', max: '20', value: String(count), style: { width: '62px' }, 'aria-label': 'Number of dice' });
    const rollBtn = el('button', { class: 'btn btn--primary grow', text: 'Roll' });
    const strip = el('div', { class: 'row wrap', style: { gap: '4px', marginTop: '8px', minHeight: '22px' } });

    root.append(
      el('div', {}, [total, detail]),
      sideTabs,
      el('div', { class: 'row' }, [countInput, rollBtn]),
      strip
    );

    countInput.addEventListener('input', () => {
      count = Math.min(20, Math.max(1, parseInt(countInput.value, 10) || 1));
      ctx.store.set('count', count);
    });

    rollBtn.addEventListener('click', () => {
      const results = Array.from({ length: count }, () => roll(sides));
      const sum = results.reduce((a, b) => a + b, 0);

      total.textContent = String(sum);
      detail.textContent = `${count}d${sides} → ${results.join(' + ')}`;

      history.unshift({ sum, label: `${count}d${sides}`, crit: count === 1 && (results[0] === sides || results[0] === 1) });
      history = history.slice(0, 10);

      strip.replaceChildren(...history.map((h, i) =>
        el('span', {
          class: `pill ${h.crit ? (h.sum === 1 ? 'pill--danger' : 'pill--ok') : i === 0 ? 'pill--accent' : ''}`,
          text: String(h.sum),
          title: h.label,
        })));

      total.animate?.(
        [{ transform: 'scale(1.12)', opacity: 0.6 }, { transform: 'scale(1)', opacity: 1 }],
        { duration: 220, easing: 'cubic-bezier(.22,1,.36,1)' }
      );
    });
  },
});
