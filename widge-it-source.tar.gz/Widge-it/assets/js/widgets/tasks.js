import { defineWidget } from '../core/registry.js';
import { el, icon, uid } from '../core/util.js';

export default defineWidget({
  id: 'tasks',
  name: 'Task List',
  category: 'Productivity',
  size: 'tall',
  description: 'A quick checklist that remembers itself between visits.',
  keywords: ['todo', 'checklist', 'tasks', 'done'],
  icon: icon('<path d="M9 6h11M9 12h11M9 18h11"/><path d="m3.5 6 1.2 1.2L7 5M3.5 12l1.2 1.2L7 11M3.5 18l1.2 1.2L7 17"/>'),

  mount(root, ctx) {
    let items = ctx.store.get('items', [
      { id: uid(), text: 'Review the widget layout', done: false },
      { id: uid(), text: 'Pick favourites to keep', done: false },
      { id: uid(), text: 'Ship it', done: true },
    ]);

    const input = el('input', { class: 'field', placeholder: 'Add a task…  ⏎', 'aria-label': 'New task' });
    const list = el('div', { class: 'list fill', style: { marginTop: '8px' } });
    const fill = el('div', { class: 'bar__fill' });
    const stat = el('span', { class: 'tiny dim' });
    const clearBtn = el('button', { class: 'btn btn--sm btn--ghost tiny', text: 'Clear done' });

    root.append(
      input,
      list,
      el('div', { style: { marginTop: '8px' } }, [
        el('div', { class: 'bar bar--thin', style: { marginBottom: '6px' } }, fill),
        el('div', { class: 'row row--between' }, [stat, clearBtn]),
      ])
    );

    const save = () => { ctx.store.set('items', items); render(); };

    input.addEventListener('keydown', (e) => {
      if (e.key !== 'Enter' || !input.value.trim()) return;
      items.unshift({ id: uid(), text: input.value.trim(), done: false });
      input.value = '';
      save();
    });

    clearBtn.addEventListener('click', () => { items = items.filter((i) => !i.done); save(); });

    function render() {
      list.replaceChildren(...items.map((item) => {
        const box = el('button', {
          'aria-label': item.done ? 'Mark incomplete' : 'Mark complete',
          style: {
            width: '17px', height: '17px', flex: 'none', borderRadius: '6px',
            border: `1.5px solid ${item.done ? 'var(--accent)' : 'var(--line-strong)'}`,
            background: item.done ? 'var(--accent)' : 'transparent',
            display: 'grid', placeItems: 'center', color: '#06070c',
          },
          html: item.done ? '<svg viewBox="0 0 24 24" style="width:11px;height:11px;stroke-width:3"><path d="m4 12 5.5 5.5L20 7"/></svg>' : '',
          onclick: () => { item.done = !item.done; save(); },
        });

        const label = el('span', {
          class: 'grow',
          text: item.text,
          style: {
            color: item.done ? 'var(--text-3)' : 'var(--text)',
            textDecoration: item.done ? 'line-through' : 'none',
            overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap',
          },
        });

        const del = el('button', {
          class: 'card__tool', title: 'Delete',
          html: icon('<path d="M18 6 6 18M6 6l12 12"/>'),
          onclick: () => { items = items.filter((i) => i.id !== item.id); save(); },
        });

        return el('div', { class: 'list__item' }, [box, label, del]);
      }));

      if (!items.length) list.append(el('div', { class: 'notice', text: 'Nothing on the list. Enjoy it.' }));

      const done = items.filter((i) => i.done).length;
      fill.style.width = items.length ? `${(done / items.length) * 100}%` : '0%';
      stat.textContent = items.length ? `${done} of ${items.length} complete` : 'No tasks';
    }

    render();
  },
});
