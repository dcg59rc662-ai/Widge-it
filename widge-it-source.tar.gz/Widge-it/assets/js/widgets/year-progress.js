import { defineWidget } from '../core/registry.js';
import { el, icon, clamp } from '../core/util.js';

const pct = (start, end, now) => clamp((now - start) / (end - start), 0, 1) * 100;

export default defineWidget({
  id: 'year-progress',
  name: 'Time Elapsed',
  category: 'Time',
  size: 'md',
  description: 'How much of the day, week, month and year has already gone.',
  keywords: ['progress', 'year', 'week', 'month', 'percent'],
  icon: icon('<path d="M3 12h18"/><rect x="3" y="8" width="11" height="8" rx="3"/>'),

  mount(root, ctx) {
    const bars = [
      { label: 'Day' }, { label: 'Week' }, { label: 'Month' }, { label: 'Year' },
    ].map((b) => {
      const value = el('span', { class: 'mono tiny', style: { color: 'var(--text-2)' } });
      const fill = el('div', { class: 'bar__fill', style: { width: '0%' } });
      const node = el('div', { style: { marginBottom: '11px' } }, [
        el('div', { class: 'row row--between', style: { marginBottom: '5px' } }, [
          el('span', { class: 'tiny', style: { color: 'var(--text-2)', fontWeight: '550' }, text: b.label }),
          value,
        ]),
        el('div', { class: 'bar' }, fill),
      ]);
      root.append(node);
      return { ...b, value, fill };
    });

    const remain = el('div', { class: 'tiny dim', style: { marginTop: 'auto' } });
    root.append(remain);

    ctx.every(30000, () => {
      const now = new Date();

      const dayStart = new Date(now); dayStart.setHours(0, 0, 0, 0);
      const dayEnd = new Date(dayStart); dayEnd.setDate(dayEnd.getDate() + 1);

      const weekStart = new Date(dayStart);
      weekStart.setDate(weekStart.getDate() - ((weekStart.getDay() + 6) % 7)); // Monday
      const weekEnd = new Date(weekStart); weekEnd.setDate(weekEnd.getDate() + 7);

      const monthStart = new Date(now.getFullYear(), now.getMonth(), 1);
      const monthEnd = new Date(now.getFullYear(), now.getMonth() + 1, 1);

      const yearStart = new Date(now.getFullYear(), 0, 1);
      const yearEnd = new Date(now.getFullYear() + 1, 0, 1);

      const values = [
        pct(dayStart, dayEnd, now),
        pct(weekStart, weekEnd, now),
        pct(monthStart, monthEnd, now),
        pct(yearStart, yearEnd, now),
      ];

      bars.forEach((b, i) => {
        b.fill.style.width = `${values[i].toFixed(1)}%`;
        b.value.textContent = `${values[i].toFixed(1)}%`;
      });

      const daysLeft = Math.ceil((yearEnd - now) / 86400000);
      remain.textContent = `${daysLeft} day${daysLeft === 1 ? '' : 's'} left in ${now.getFullYear()}`;
    });
  },
});
