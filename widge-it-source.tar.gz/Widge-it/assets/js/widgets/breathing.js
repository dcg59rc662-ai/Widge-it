import { defineWidget } from '../core/registry.js';
import { el, icon, clamp } from '../core/util.js';

const PATTERNS = {
  Box:      { steps: [['Inhale', 4], ['Hold', 4], ['Exhale', 4], ['Hold', 4]] },
  '4-7-8':  { steps: [['Inhale', 4], ['Hold', 7], ['Exhale', 8]] },
  Calm:     { steps: [['Inhale', 5], ['Exhale', 5]] },
};

export default defineWidget({
  id: 'breathing',
  name: 'Breathing',
  category: 'Wellbeing',
  size: 'tall',
  description: 'Paced breathing — box, 4-7-8 or coherent rhythm.',
  keywords: ['calm', 'meditation', 'anxiety', 'focus', 'breathe'],
  icon: icon('<circle cx="12" cy="12" r="3.5"/><circle cx="12" cy="12" r="9" opacity=".5"/>'),

  mount(root, ctx) {
    let pattern = ctx.store.get('pattern', 'Box');
    if (!PATTERNS[pattern]) pattern = 'Box';
    let running = false;
    let phaseStart = 0;
    let step = 0;
    let cycles = 0;

    const tabs = el('div', { class: 'tabs' });
    const tabBtns = Object.keys(PATTERNS).map((name) =>
      el('button', {
        class: `tabs__btn${name === pattern ? ' is-active' : ''}`,
        text: name,
        onclick: () => {
          pattern = name;
          ctx.store.set('pattern', name);
          tabBtns.forEach((b, i) => b.classList.toggle('is-active', Object.keys(PATTERNS)[i] === name));
          reset();
        },
      }));
    tabs.append(...tabBtns);

    const orb = el('div', {
      style: {
        width: '104px', height: '104px', borderRadius: '50%',
        background: 'var(--gradient)',
        display: 'grid', placeItems: 'center',
        transition: 'transform 120ms linear',
        boxShadow: '0 16px 44px -18px var(--accent)',
      },
    });
    const inner = el('div', {
      class: 'mono',
      style: { fontSize: '22px', fontWeight: '700', color: '#06070c' },
      text: '4',
    });
    orb.append(inner);

    const stage = el('div', { class: 'canvas-wrap fill', style: { padding: '14px 0' } }, orb);
    const phaseLabel = el('div', { class: 'small', style: { textAlign: 'center', fontWeight: '600' }, text: 'Ready' });
    const cycleOut = el('div', { class: 'tiny dim', style: { textAlign: 'center' } });
    const toggle = el('button', { class: 'btn btn--primary btn--block', text: 'Begin', style: { marginTop: '10px' } });

    root.append(tabs, stage, phaseLabel, cycleOut, toggle);

    function reset() {
      running = false;
      step = 0;
      cycles = 0;
      toggle.textContent = 'Begin';
      phaseLabel.textContent = 'Ready';
      orb.style.transform = 'scale(.72)';
      inner.textContent = String(PATTERNS[pattern].steps[0][1]);
      cycleOut.textContent = '';
    }

    toggle.addEventListener('click', () => {
      running = !running;
      toggle.textContent = running ? 'Pause' : 'Resume';
      if (running) phaseStart = performance.now();
    });

    ctx.frame((now) => {
      if (!running) return;
      const steps = PATTERNS[pattern].steps;
      const [name, seconds] = steps[step];
      const progress = clamp((now - phaseStart) / (seconds * 1000), 0, 1);

      if (progress >= 1) {
        step = (step + 1) % steps.length;
        if (step === 0) cycles++;
        phaseStart = now;
        return;
      }

      // Scale follows the phase: grow on inhale, hold, shrink on exhale.
      const scale = name === 'Inhale' ? 0.72 + progress * 0.28
        : name === 'Exhale' ? 1 - progress * 0.28
        : step === 0 || steps[step - 1]?.[0] === 'Inhale' ? 1 : 0.72;

      orb.style.transform = `scale(${scale.toFixed(3)})`;
      inner.textContent = String(Math.ceil(seconds * (1 - progress)));
      phaseLabel.textContent = name;
      cycleOut.textContent = `${cycles} cycle${cycles === 1 ? '' : 's'} · ${steps.map((s) => s[1]).join('–')}`;
    });

    reset();
  },
});
