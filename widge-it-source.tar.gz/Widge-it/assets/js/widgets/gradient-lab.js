import { defineWidget } from '../core/registry.js';
import { el, icon, copy, flash, rgbToHex, hslToRgb } from '../core/util.js';

const TYPES = ['linear', 'radial', 'conic'];

export default defineWidget({
  id: 'gradient-lab',
  name: 'Gradient Lab',
  category: 'Tools',
  size: 'md',
  description: 'Design a CSS gradient and copy the rule straight out.',
  keywords: ['css', 'gradient', 'design', 'background', 'colour'],
  icon: icon('<rect x="3" y="3" width="18" height="18" rx="4"/><path d="M3 15 15 3M8 21 21 8"/>'),

  mount(root, ctx) {
    const state = ctx.store.get('state', { a: '#6d8bff', b: '#3ddbc0', angle: 135, type: 'linear' });

    const preview = el('div', {
      class: 'fill',
      style: { borderRadius: '12px', border: '1px solid var(--line)', minHeight: '70px' },
    });

    const code = el('div', {
      class: 'mono tiny',
      style: {
        padding: '8px 9px', borderRadius: '9px', background: 'var(--card)',
        border: '1px solid var(--line)', color: 'var(--text-2)',
        wordBreak: 'break-all', margin: '10px 0 8px', lineHeight: '1.5',
      },
    });

    const colorA = el('input', { type: 'color', value: state.a, class: 'swatch-input', 'aria-label': 'First colour' });
    const colorB = el('input', { type: 'color', value: state.b, class: 'swatch-input', 'aria-label': 'Second colour' });
    for (const c of [colorA, colorB]) {
      c.style.cssText = 'width:32px;height:32px;border:none;background:none;padding:0;cursor:pointer';
    }

    const angle = el('input', { class: 'range grow', type: 'range', min: '0', max: '360', value: String(state.angle), 'aria-label': 'Angle' });
    const angleOut = el('span', { class: 'mono tiny', style: { width: '34px', textAlign: 'right' } });

    const typeTabs = el('div', { class: 'tabs', style: { marginBottom: '8px' } });
    const typeBtns = TYPES.map((t) =>
      el('button', {
        class: `tabs__btn${t === state.type ? ' is-active' : ''}`,
        text: t[0].toUpperCase() + t.slice(1),
        onclick: () => {
          state.type = t;
          typeBtns.forEach((b, i) => b.classList.toggle('is-active', TYPES[i] === t));
          render();
        },
      }));
    typeTabs.append(...typeBtns);

    const shuffle = el('button', { class: 'btn btn--sm grow', text: 'Shuffle' });
    const copyBtn = el('button', { class: 'btn btn--sm btn--primary grow', text: 'Copy CSS' });
    const note = el('span', { class: 'flash tiny' });

    root.append(
      preview, code, typeTabs,
      el('div', { class: 'row' }, [colorA, angle, angleOut, colorB]),
      el('div', { class: 'row', style: { marginTop: '8px' } }, [shuffle, copyBtn]),
      el('div', { class: 'row', style: { justifyContent: 'flex-end' } }, note)
    );

    const css = () =>
      state.type === 'linear' ? `linear-gradient(${state.angle}deg, ${state.a}, ${state.b})`
      : state.type === 'radial' ? `radial-gradient(circle at 30% 30%, ${state.a}, ${state.b})`
      : `conic-gradient(from ${state.angle}deg, ${state.a}, ${state.b}, ${state.a})`;

    function render() {
      const value = css();
      preview.style.background = value;
      code.textContent = `background: ${value};`;
      angleOut.textContent = `${state.angle}°`;
      angle.disabled = state.type === 'radial';
      angle.style.opacity = state.type === 'radial' ? '.4' : '1';
      ctx.store.set('state', state);
    }

    colorA.addEventListener('input', () => { state.a = colorA.value; render(); });
    colorB.addEventListener('input', () => { state.b = colorB.value; render(); });
    angle.addEventListener('input', () => { state.angle = Number(angle.value); render(); });

    shuffle.addEventListener('click', () => {
      const h = Math.random() * 360;
      state.a = rgbToHex(...hslToRgb(h, 70, 62));
      state.b = rgbToHex(...hslToRgb(h + 40 + Math.random() * 120, 70, 55));
      state.angle = Math.round(Math.random() * 360);
      colorA.value = state.a;
      colorB.value = state.b;
      angle.value = String(state.angle);
      render();
    });

    copyBtn.addEventListener('click', async () =>
      flash(note, (await copy(`background: ${css()};`)) ? 'CSS copied' : 'Copy failed'));

    render();
  },
});
