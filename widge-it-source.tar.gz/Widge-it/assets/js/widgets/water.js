import { defineWidget } from '../core/registry.js';
import { el, icon } from '../core/util.js';

const today = () => new Date().toISOString().slice(0, 10);

export default defineWidget({
  id: 'water',
  name: 'Hydration',
  category: 'Wellbeing',
  size: 'sm',
  description: 'Track glasses of water against a daily goal. Resets each day.',
  keywords: ['water', 'drink', 'health', 'daily', 'goal'],
  icon: icon('<path d="M12 3s6 6.4 6 10.2A6 6 0 0 1 6 13.2C6 9.4 12 3 12 3Z"/>'),

  mount(root, ctx) {
    const goal = 8;
    let log = ctx.store.get('log', { date: today(), count: 0 });
    if (log.date !== today()) log = { date: today(), count: 0 };

    const count = el('span', { class: 'metric__value' });
    const of = el('span', { class: 'metric__unit', text: `/ ${goal} glasses` });
    const glasses = el('div', { class: 'row', style: { gap: '4px', margin: '10px 0 8px', flexWrap: 'wrap' } });
    const minus = el('button', { class: 'btn btn--sm btn--icon', text: '−' });
    const plus = el('button', { class: 'btn btn--sm btn--primary grow', text: '+ Glass' });

    root.append(
      el('div', { class: 'metric' }, [count, of]),
      glasses,
      el('div', { class: 'row', style: { marginTop: 'auto' } }, [minus, plus])
    );

    const save = () => { ctx.store.set('log', log); render(); };

    function render() {
      count.textContent = String(log.count);
      glasses.replaceChildren(...Array.from({ length: goal }, (_, i) =>
        el('span', {
          style: {
            flex: '1 1 0', height: '20px', borderRadius: '5px',
            background: i < log.count ? 'var(--accent)' : 'var(--track)',
            transition: 'background 200ms',
          },
        })));
    }

    plus.addEventListener('click', () => { log.count = Math.min(goal * 2, log.count + 1); save(); });
    minus.addEventListener('click', () => { log.count = Math.max(0, log.count - 1); save(); });

    ctx.every(60000, () => {
      if (log.date === today()) return;
      log = { date: today(), count: 0 };
      save();
    });

    render();
  },
});
