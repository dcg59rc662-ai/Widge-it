import { defineWidget } from '../core/registry.js';
import { el, icon, flash, copy } from '../core/util.js';

export default defineWidget({
  id: 'notes',
  name: 'Scratchpad',
  category: 'Productivity',
  size: 'tall',
  description: 'A distraction-free note that autosaves as you type.',
  keywords: ['notes', 'text', 'memo', 'scratch', 'draft'],
  icon: icon('<path d="M4 5.5A2.5 2.5 0 0 1 6.5 3H18a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6.5A2.5 2.5 0 0 1 4 18.5Z"/><path d="M8 8h8M8 12h8M8 16h5"/>'),

  mount(root, ctx) {
    const area = el('textarea', {
      class: 'textarea fill',
      placeholder: 'Start typing… everything is saved locally.',
      style: { minHeight: '0', fontSize: '13px' },
    });
    area.value = ctx.store.get('text', '');

    const stats = el('span', { class: 'tiny dim' });
    const saved = el('span', { class: 'flash tiny' });
    const copyBtn = el('button', { class: 'btn btn--sm btn--ghost', html: icon('<rect x="9" y="9" width="11" height="11" rx="2"/><path d="M5 15V5a2 2 0 0 1 2-2h8"/>'), title: 'Copy all' });

    root.append(area, el('div', { class: 'row row--between', style: { marginTop: '8px' } }, [
      stats, el('div', { class: 'row', style: { gap: '6px' } }, [saved, copyBtn]),
    ]));

    const count = () => {
      const text = area.value;
      const words = text.trim() ? text.trim().split(/\s+/).length : 0;
      stats.textContent = `${words} word${words === 1 ? '' : 's'} · ${text.length} chars`;
    };

    let timer;
    area.addEventListener('input', () => {
      count();
      clearTimeout(timer);
      timer = setTimeout(() => {
        ctx.store.set('text', area.value);
        flash(saved, 'Saved', 900);
      }, 400);
    });
    ctx.onCleanup(() => clearTimeout(timer));

    copyBtn.addEventListener('click', async () => {
      flash(saved, (await copy(area.value)) ? 'Copied' : 'Copy failed');
    });

    count();
  },
});
