import { defineWidget } from '../core/registry.js';
import { el, icon, pad2 } from '../core/util.js';

const defaultTarget = () => {
  const d = new Date();
  d.setMonth(11, 31); d.setHours(23, 59, 0, 0);
  return d.toISOString().slice(0, 16);
};

export default defineWidget({
  id: 'countdown',
  name: 'Countdown',
  category: 'Time',
  size: 'md',
  description: 'Counts down to any date you set — launches, birthdays, deadlines.',
  keywords: ['timer', 'deadline', 'event', 'until'],
  icon: icon('<circle cx="12" cy="13" r="8"/><path d="M12 9.5V13l2.5 1.5M9 2h6"/>'),

  mount(root, ctx) {
    const label = el('input', { class: 'field', placeholder: 'Event name', value: ctx.store.get('label', 'New Year') });
    const when = el('input', { class: 'field mono', type: 'datetime-local', value: ctx.store.get('when', defaultTarget()) });

    const units = ['Days', 'Hours', 'Min', 'Sec'].map((u) => {
      const v = el('div', { class: 'mono', style: { fontSize: '22px', fontWeight: '700', letterSpacing: '-.02em' }, text: '00' });
      return { node: el('div', { style: { textAlign: 'center' } }, [v, el('div', { class: 'tiny dim', text: u })]), v };
    });

    const clock = el('div', {
      style: { display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '6px', padding: '14px 0 10px' },
    }, units.map((u) => u.node));

    const status = el('div', { class: 'tiny dim', style: { marginBottom: '8px' } });

    root.append(status, clock, el('div', { class: 'col', style: { marginTop: 'auto' } }, [label, when]));

    const save = () => {
      ctx.store.set('label', label.value);
      ctx.store.set('when', when.value);
      tick();
    };
    label.addEventListener('input', save);
    when.addEventListener('change', save);

    function tick() {
      const target = new Date(when.value);
      if (Number.isNaN(target.valueOf())) {
        status.textContent = 'Pick a date to count down to';
        units.forEach((u) => (u.v.textContent = '––'));
        return;
      }

      let diff = (target - Date.now()) / 1000;
      const past = diff < 0;
      diff = Math.abs(diff);

      const d = Math.floor(diff / 86400);
      const h = Math.floor((diff % 86400) / 3600);
      const m = Math.floor((diff % 3600) / 60);
      const s = Math.floor(diff % 60);

      [d, h, m, s].forEach((n, i) => (units[i].v.textContent = i === 0 ? String(n) : pad2(n)));
      status.innerHTML = `<span class="pill ${past ? '' : 'pill--accent'}">${past ? 'Since' : 'Until'}</span> `
        + `<span style="margin-left:6px">${label.value || 'your event'}</span>`;
    }

    ctx.every(1000, tick);
  },
});
