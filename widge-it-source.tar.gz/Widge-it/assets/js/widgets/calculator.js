import { defineWidget } from '../core/registry.js';
import { el, icon } from '../core/util.js';

const KEYS = [
  ['AC', 'fn'], ['±', 'fn'], ['%', 'fn'], ['÷', 'op'],
  ['7', ''], ['8', ''], ['9', ''], ['×', 'op'],
  ['4', ''], ['5', ''], ['6', ''], ['−', 'op'],
  ['1', ''], ['2', ''], ['3', ''], ['+', 'op'],
  ['0', 'zero'], ['.', ''], ['=', 'eq'],
];

const apply = (a, op, b) => {
  switch (op) {
    case '+': return a + b;
    case '−': return a - b;
    case '×': return a * b;
    case '÷': return b === 0 ? NaN : a / b;
    default:  return b;
  }
};

const show = (n) => {
  if (!Number.isFinite(n)) return 'Error';
  const abs = Math.abs(n);
  if (abs !== 0 && (abs >= 1e12 || abs < 1e-6)) return n.toExponential(4);
  return String(Number(n.toPrecision(12)));
};

export default defineWidget({
  id: 'calculator',
  name: 'Calculator',
  category: 'Tools',
  size: 'tall',
  description: 'A precise four-function calculator with full keyboard support.',
  keywords: ['math', 'arithmetic', 'compute', 'numbers'],
  icon: icon('<rect x="4" y="3" width="16" height="18" rx="3"/><path d="M8 7h8M8 12h.01M12 12h.01M16 12h.01M8 16h.01M12 16h.01M16 16h.01"/>'),

  mount(root, ctx) {
    let current = '0';    // digits being typed
    let stored = null;    // left-hand operand
    let op = null;        // pending operator
    let fresh = true;     // next digit starts a new number

    const history = el('div', { class: 'tiny dim mono', style: { textAlign: 'right', minHeight: '15px' } });
    const display = el('div', {
      class: 'mono',
      style: {
        textAlign: 'right', fontSize: 'clamp(22px, 9cqw, 30px)', fontWeight: '700',
        letterSpacing: '-.03em', overflow: 'hidden', textOverflow: 'ellipsis', marginBottom: '10px',
      },
    });

    const pad = el('div', { class: 'pad', style: { gridTemplateColumns: 'repeat(4, 1fr)' } });
    root.append(history, display, pad);

    const paint = () => {
      display.textContent = current;
      history.textContent = stored != null ? `${show(stored)} ${op ?? ''}` : '';
    };

    function press(key) {
      if (/^\d$/.test(key)) {
        current = fresh || current === '0' ? key : current + key;
        fresh = false;
      } else if (key === '.') {
        if (fresh) { current = '0.'; fresh = false; }
        else if (!current.includes('.')) current += '.';
      } else if (key === 'AC') {
        current = '0'; stored = null; op = null; fresh = true;
      } else if (key === '±') {
        current = current.startsWith('-') ? current.slice(1) : `-${current}`;
      } else if (key === '%') {
        current = show(parseFloat(current) / 100); fresh = true;
      } else if (['+', '−', '×', '÷'].includes(key)) {
        const value = parseFloat(current);
        stored = stored != null && op && !fresh ? apply(stored, op, value) : value;
        current = show(stored);
        op = key;
        fresh = true;
      } else if (key === '=') {
        if (op != null && stored != null) {
          current = show(apply(stored, op, parseFloat(current)));
          stored = null; op = null;
        }
        fresh = true;
      }
      paint();
    }

    for (const [label, cls] of KEYS) {
      const btn = el('button', { class: cls === 'zero' ? '' : cls, text: label, onclick: () => press(label) });
      if (cls === 'zero') btn.style.gridColumn = 'span 2';
      pad.append(btn);
    }

    const MAP = { '/': '÷', '*': '×', '-': '−', '+': '+', Enter: '=', '=': '=', Escape: 'AC', c: 'AC', C: 'AC' };
    ctx.on(document, 'keydown', (e) => {
      if (!root.closest('.card')?.matches(':hover') && document.activeElement?.closest('.card') !== root.closest('.card')) return;
      const key = MAP[e.key] ?? (/^[\d.]$/.test(e.key) ? e.key : null);
      if (e.key === 'Backspace') {
        e.preventDefault();
        current = current.length > 1 ? current.slice(0, -1) : '0';
        return paint();
      }
      if (!key) return;
      e.preventDefault();
      press(key);
    });

    paint();
  },
});
