import { defineWidget } from '../core/registry.js';
import { el, icon } from '../core/util.js';

const WEEKDAYS = ['M', 'T', 'W', 'T', 'F', 'S', 'S'];

export default defineWidget({
  id: 'calendar',
  name: 'Calendar',
  category: 'Time',
  size: 'md',
  description: 'Month view with today highlighted and week numbers.',
  keywords: ['month', 'date', 'schedule', 'days'],
  icon: icon('<rect x="3" y="5" width="18" height="16" rx="3"/><path d="M3 10h18M8 3v4M16 3v4"/>'),

  mount(root, ctx) {
    let cursor = new Date();
    cursor.setDate(1);

    const title = el('div', { class: 'small', style: { fontWeight: '600' } });
    const prev = el('button', { class: 'btn btn--sm btn--ghost', html: icon('<path d="m14 6-6 6 6 6"/>') });
    const next = el('button', { class: 'btn btn--sm btn--ghost', html: icon('<path d="m10 6 6 6-6 6"/>') });
    const today = el('button', { class: 'btn btn--sm', text: 'Today' });

    const head = el('div', { class: 'row row--between', style: { marginBottom: '8px' } }, [
      title,
      el('div', { class: 'row', style: { gap: '2px' } }, [prev, next, today]),
    ]);

    const grid = el('div', {
      class: 'fill',
      style: { display: 'grid', gridTemplateColumns: 'repeat(7, 1fr)', gridAutoRows: 'minmax(0, 1fr)', gap: '2px' },
    });

    root.append(head, grid);

    prev.onclick = () => { cursor.setMonth(cursor.getMonth() - 1); render(); };
    next.onclick = () => { cursor.setMonth(cursor.getMonth() + 1); render(); };
    today.onclick = () => { cursor = new Date(); cursor.setDate(1); render(); };

    function render() {
      title.textContent = cursor.toLocaleDateString(undefined, { month: 'long', year: 'numeric' });
      grid.replaceChildren();

      for (const d of WEEKDAYS) {
        grid.append(el('div', {
          class: 'tiny dim',
          style: { textAlign: 'center', fontWeight: '600', paddingBottom: '2px' },
          text: d,
        }));
      }

      const first = new Date(cursor.getFullYear(), cursor.getMonth(), 1);
      const offset = (first.getDay() + 6) % 7;              // Monday-first
      const daysInMonth = new Date(cursor.getFullYear(), cursor.getMonth() + 1, 0).getDate();
      const now = new Date();

      for (let i = 0; i < offset; i++) grid.append(el('div'));

      for (let day = 1; day <= daysInMonth; day++) {
        const isToday = day === now.getDate()
          && cursor.getMonth() === now.getMonth()
          && cursor.getFullYear() === now.getFullYear();
        const dow = new Date(cursor.getFullYear(), cursor.getMonth(), day).getDay();
        const weekend = dow === 0 || dow === 6;

        grid.append(el('div', {
          class: 'mono',
          style: {
            display: 'grid', placeItems: 'center',
            fontSize: '12px',
            borderRadius: '8px',
            color: isToday ? '#06070c' : weekend ? 'var(--text-3)' : 'var(--text-2)',
            background: isToday ? 'var(--accent)' : 'transparent',
            fontWeight: isToday ? '700' : '500',
          },
          text: String(day),
        }));
      }
    }

    render();
    ctx.every(3600000, render);
  },
});
