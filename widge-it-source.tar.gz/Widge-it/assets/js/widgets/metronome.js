import { defineWidget } from '../core/registry.js';
import { el, icon, clamp } from '../core/util.js';

const SIGNATURES = [2, 3, 4, 6];

export default defineWidget({
  id: 'metronome',
  name: 'Metronome',
  category: 'Sensors',
  size: 'md',
  description: 'Sample-accurate click track with accented downbeats.',
  keywords: ['bpm', 'tempo', 'music', 'practice', 'beat'],
  icon: icon('<path d="M9 3h6l4 18H5L9 3Z"/><path d="m12 20 5-11"/>'),

  mount(root, ctx) {
    let bpm = ctx.store.get('bpm', 100);
    let beats = ctx.store.get('beats', 4);
    let running = false;
    let audio = null;
    let nextNoteTime = 0;
    let beatIndex = 0;

    const bpmOut = el('span', { class: 'metric__value', text: String(bpm) });
    const dots = el('div', { class: 'row', style: { gap: '6px', justifyContent: 'center', padding: '12px 0' } });
    const range = el('input', { class: 'range', type: 'range', min: '30', max: '240', value: String(bpm), 'aria-label': 'Tempo' });
    const playBtn = el('button', { class: 'btn btn--primary grow', text: 'Start' });
    const tapBtn = el('button', { class: 'btn', text: 'Tap' });

    const sigTabs = el('div', { class: 'tabs', style: { marginBottom: '8px' } });
    const sigBtns = SIGNATURES.map((n) =>
      el('button', {
        class: `tabs__btn${n === beats ? ' is-active' : ''}`,
        text: `${n}/4`,
        onclick: () => {
          beats = n;
          ctx.store.set('beats', n);
          sigBtns.forEach((b, i) => b.classList.toggle('is-active', SIGNATURES[i] === n));
          renderDots();
        },
      }));
    sigTabs.append(...sigBtns);

    root.append(
      el('div', { class: 'row row--between' }, [
        el('div', { class: 'metric' }, [bpmOut, el('span', { class: 'metric__unit', text: 'bpm' })]),
        el('span', { class: 'pill', 'data-ref': 'tempoName' }),
      ]),
      dots, range, sigTabs,
      el('div', { class: 'row' }, [playBtn, tapBtn])
    );

    const tempoName = root.querySelector('[data-ref="tempoName"]');
    let dotEls = [];

    function renderDots() {
      dotEls = Array.from({ length: beats }, (_, i) =>
        el('span', {
          style: {
            width: i === 0 ? '12px' : '9px', height: i === 0 ? '12px' : '9px',
            borderRadius: '50%',
            background: 'var(--track)',
            transition: 'background 90ms, transform 90ms',
          },
        }));
      dots.replaceChildren(...dotEls);
    }

    function nameFor(v) {
      return v < 60 ? 'Largo' : v < 76 ? 'Adagio' : v < 108 ? 'Andante'
        : v < 120 ? 'Moderato' : v < 156 ? 'Allegro' : v < 200 ? 'Vivace' : 'Presto';
    }

    function setBpm(value) {
      bpm = clamp(Math.round(value), 30, 240);
      bpmOut.textContent = String(bpm);
      range.value = String(bpm);
      tempoName.textContent = nameFor(bpm);
      ctx.store.set('bpm', bpm);
    }

    /** Schedule clicks slightly ahead of time — setInterval alone drifts audibly. */
    function scheduler() {
      if (!running || !audio) return;
      while (nextNoteTime < audio.currentTime + 0.12) {
        click(nextNoteTime, beatIndex === 0);
        flashDot(beatIndex, nextNoteTime);
        nextNoteTime += 60 / bpm;
        beatIndex = (beatIndex + 1) % beats;
      }
    }

    function click(time, accent) {
      const osc = audio.createOscillator();
      const gain = audio.createGain();
      osc.frequency.value = accent ? 1600 : 1000;
      gain.gain.setValueAtTime(0.0001, time);
      gain.gain.exponentialRampToValueAtTime(accent ? 0.5 : 0.28, time + 0.002);
      gain.gain.exponentialRampToValueAtTime(0.0001, time + 0.06);
      osc.connect(gain).connect(audio.destination);
      osc.start(time);
      osc.stop(time + 0.08);
    }

    function flashDot(index, time) {
      const delay = Math.max(0, (time - audio.currentTime) * 1000);
      setTimeout(() => {
        const dot = dotEls[index];
        if (!dot) return;
        dot.style.background = index === 0 ? 'var(--accent)' : 'var(--text-2)';
        dot.style.transform = 'scale(1.35)';
        setTimeout(() => {
          dot.style.background = 'var(--track)';
          dot.style.transform = 'scale(1)';
        }, 110);
      }, delay);
    }

    playBtn.addEventListener('click', () => {
      running = !running;
      playBtn.textContent = running ? 'Stop' : 'Start';
      playBtn.classList.toggle('btn--primary', !running);

      if (running) {
        const AC = window.AudioContext || window.webkitAudioContext;
        audio = audio || new AC();
        audio.resume?.();
        beatIndex = 0;
        nextNoteTime = audio.currentTime + 0.06;
      }
    });

    let taps = [];
    tapBtn.addEventListener('click', () => {
      const now = performance.now();
      taps = taps.filter((t) => now - t < 2500);
      taps.push(now);
      if (taps.length < 2) return;
      const gaps = taps.slice(1).map((t, i) => t - taps[i]);
      setBpm(60000 / (gaps.reduce((a, b) => a + b, 0) / gaps.length));
    });

    range.addEventListener('input', () => setBpm(Number(range.value)));

    ctx.every(25, scheduler);
    ctx.onCleanup(() => { running = false; audio?.close().catch(() => {}); });

    renderDots();
    setBpm(bpm);
  },
});
