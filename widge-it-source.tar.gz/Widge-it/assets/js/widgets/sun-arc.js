import { defineWidget } from '../core/registry.js';
import { el, fitCanvas, cssVar, icon, clamp, hms } from '../core/util.js';
import { sunTimes, sunPosition } from '../lib/astro.js';
import { guessLocation, requestLocation, formatCoords } from '../lib/geo.js';

const time = (d) => d ? d.toLocaleTimeString(undefined, { hour: '2-digit', minute: '2-digit' }) : '—';

export default defineWidget({
  id: 'sun-arc',
  name: 'Sun Tracker',
  category: 'Time',
  size: 'lg',
  description: 'Sunrise, sunset, golden hour and the sun’s live position in the sky.',
  keywords: ['sunrise', 'sunset', 'daylight', 'golden hour', 'dusk', 'dawn'],
  icon: icon('<circle cx="12" cy="12" r="4"/><path d="M12 3v2M12 19v2M4.2 4.2l1.4 1.4M18.4 18.4l1.4 1.4M3 12h2M19 12h2M4.2 19.8l1.4-1.4M18.4 5.6l1.4-1.4"/>'),

  mount(root, ctx) {
    let place = guessLocation();

    const canvas = el('canvas', { style: { width: '100%', height: '100%' } });
    const wrap = el('div', { class: 'canvas-wrap', style: { minHeight: '90px' } }, canvas);

    const locBtn = el('button', { class: 'btn btn--sm', text: 'Locate me' });
    const head = el('div', { class: 'row row--between', style: { marginBottom: '4px' } }, [
      el('div', {}, [
        el('span', { class: 'small', 'data-ref': 'place', style: { fontWeight: '550' } }),
        el('span', { class: 'tiny dim', 'data-ref': 'coords', style: { marginLeft: '6px' } }),
      ]),
      locBtn,
    ]);

    const stats = el('div', { style: { display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '8px', paddingTop: '10px' } });
    const cells = ['Sunrise', 'Sunset', 'Daylight', 'Golden hour'].map((label) => {
      const value = el('div', { class: 'mono', style: { fontSize: '14px', fontWeight: '600' }, text: '—' });
      stats.append(el('div', {}, [el('div', { class: 'tiny dim', text: label }), value]));
      return value;
    });

    root.append(head, wrap, stats);
    const placeOut = head.querySelector('[data-ref="place"]');
    const coordsOut = head.querySelector('[data-ref="coords"]');
    const c2d = canvas.getContext('2d');

    locBtn.addEventListener('click', async () => {
      locBtn.textContent = 'Locating…';
      try {
        place = await requestLocation();
        locBtn.textContent = 'Located';
        locBtn.classList.add('is-on');
      } catch {
        locBtn.textContent = 'Unavailable';
      }
      update();
    });

    function update() {
      const now = new Date();
      const t = sunTimes(now, place.lat, place.lon);
      const pos = sunPosition(now, place.lat, place.lon);

      placeOut.textContent = place.label;
      coordsOut.textContent = formatCoords(place);

      cells[0].textContent = time(t.sunrise);
      cells[1].textContent = time(t.sunset);
      cells[2].textContent = t.sunrise && t.sunset
        ? hms((t.sunset - t.sunrise) / 1000, true).slice(0, -3) + ' h'
        : t.polarDay ? '24 h' : '0 h';
      cells[3].textContent = time(t.goldenHour);

      draw(t, pos, now);
    }

    function draw(t, pos, now) {
      const { w, h } = fitCanvas(canvas, c2d);
      if (w < 10 || h < 10) return;

      const accent = cssVar('--accent', '#6d8bff');
      const warn = cssVar('--warn', '#ffc46b');
      const line = cssVar('--line', 'rgba(255,255,255,.1)');
      const dim = cssVar('--text-3', '#888');

      const padX = 14;
      const horizon = h - 18;
      const top = 10;
      const arcW = w - padX * 2;
      const arcH = horizon - top;

      c2d.clearRect(0, 0, w, h);

      // Arc path: a half-ellipse from sunrise (left) to sunset (right)
      const pointAt = (f) => {
        const a = Math.PI * clamp(f, 0, 1);
        return { x: padX + arcW * f, y: horizon - Math.sin(a) * arcH };
      };

      c2d.beginPath();
      for (let i = 0; i <= 100; i++) {
        const p = pointAt(i / 100);
        i ? c2d.lineTo(p.x, p.y) : c2d.moveTo(p.x, p.y);
      }
      c2d.strokeStyle = line;
      c2d.lineWidth = 1.5;
      c2d.setLineDash([3, 4]);
      c2d.stroke();
      c2d.setLineDash([]);

      // Fraction of daylight elapsed
      let f = null;
      if (t.sunrise && t.sunset) {
        f = (now - t.sunrise) / (t.sunset - t.sunrise);
      } else if (t.polarDay) {
        f = 0.5;
      }

      if (f != null && f >= 0 && f <= 1) {
        // Travelled portion, filled
        c2d.beginPath();
        c2d.moveTo(padX, horizon);
        for (let i = 0; i <= 100; i++) {
          const p = pointAt((i / 100) * f);
          c2d.lineTo(p.x, p.y);
        }
        c2d.lineTo(pointAt(f).x, horizon);
        c2d.closePath();
        const grad = c2d.createLinearGradient(0, top, 0, horizon);
        grad.addColorStop(0, warn);
        grad.addColorStop(1, 'transparent');
        c2d.fillStyle = grad;
        c2d.globalAlpha = .22;
        c2d.fill();
        c2d.globalAlpha = 1;

        c2d.beginPath();
        for (let i = 0; i <= 100; i++) {
          const p = pointAt((i / 100) * f);
          i ? c2d.lineTo(p.x, p.y) : c2d.moveTo(p.x, p.y);
        }
        c2d.strokeStyle = warn;
        c2d.lineWidth = 2;
        c2d.stroke();

        // The sun itself
        const p = pointAt(f);
        c2d.beginPath(); c2d.arc(p.x, p.y, 13, 0, Math.PI * 2);
        c2d.fillStyle = warn; c2d.globalAlpha = .18; c2d.fill(); c2d.globalAlpha = 1;
        c2d.beginPath(); c2d.arc(p.x, p.y, 6, 0, Math.PI * 2);
        c2d.fillStyle = warn; c2d.fill();
      } else {
        // Night: mark the sun below the horizon and say when it returns.
        const before = t.sunrise && now < t.sunrise;
        const x = before ? padX : w - padX;
        c2d.beginPath(); c2d.arc(x, horizon + 7, 5, 0, Math.PI * 2);
        c2d.fillStyle = accent; c2d.globalAlpha = .55; c2d.fill(); c2d.globalAlpha = 1;

        const nextRise = before
          ? t.sunrise
          : sunTimes(new Date(now.valueOf() + 86400000), place.lat, place.lon).sunrise;
        if (nextRise) {
          const hoursAway = (nextRise - now) / 3600000;
          c2d.fillStyle = dim;
          c2d.font = `600 12px ${cssVar('--font', 'sans-serif')}`;
          c2d.textAlign = 'center';
          c2d.fillText(`Sunrise in ${hoursAway.toFixed(1)} h`, w / 2, horizon - arcH / 2);
        }
      }

      // Horizon
      c2d.beginPath();
      c2d.moveTo(0, horizon); c2d.lineTo(w, horizon);
      c2d.strokeStyle = line; c2d.lineWidth = 1; c2d.stroke();

      // Altitude label
      c2d.fillStyle = dim;
      c2d.font = `500 10px ${cssVar('--mono', 'monospace')}`;
      c2d.textAlign = 'right';
      c2d.fillText(`alt ${pos.altitude.toFixed(1)}°  az ${pos.azimuth.toFixed(0)}°`, w - 2, h - 4);
      c2d.textAlign = 'left';
      c2d.fillText(pos.altitude > 0 ? 'Above horizon' : 'Below horizon', 2, h - 4);
    }

    ctx.every(30000, update);
    ctx.next(update);
    ctx.onTheme(update);
    ctx.onResize(wrap, update);
  },
});
