import { defineWidget } from '../core/registry.js';
import { el, icon, hms } from '../core/util.js';

export default defineWidget({
  id: 'battery',
  name: 'Battery',
  category: 'System',
  size: 'sm',
  description: 'Charge level, charging state and time remaining.',
  keywords: ['power', 'charge', 'energy', 'laptop'],
  icon: icon('<rect x="2" y="7" width="17" height="10" rx="3"/><path d="M22 10.5v3"/>'),

  mount(root, ctx) {
    const level = el('span', { class: 'metric__value', text: '—' });
    const pct = el('span', { class: 'metric__unit', text: '%' });
    const status = el('span', { class: 'pill' });
    const fill = el('div', { class: 'bar__fill', style: { width: '0%' } });
    const note = el('div', { class: 'tiny dim' });

    root.append(
      el('div', { class: 'row row--between' }, [el('div', { class: 'metric' }, [level, pct]), status]),
      el('div', { class: 'bar', style: { margin: '10px 0 6px' } }, fill),
      note
    );

    if (!navigator.getBattery) {
      root.replaceChildren(el('div', { class: 'notice' }, [
        el('div', { html: icon('<rect x="2" y="7" width="17" height="10" rx="3"/><path d="M22 10.5v3M4 4l16 16"/>'), style: { color: 'var(--text-3)' } }),
        el('div', { text: 'Battery API unavailable in this browser.' }),
      ]));
      return;
    }

    navigator.getBattery().then((battery) => {
      const render = () => {
        const p = Math.round(battery.level * 100);
        level.textContent = String(p);
        fill.style.width = `${p}%`;
        fill.style.background = p <= 15 && !battery.charging
          ? 'var(--danger)'
          : p <= 35 && !battery.charging ? 'var(--warn)' : 'var(--gradient)';

        status.textContent = battery.charging ? 'Charging' : 'On battery';
        status.className = `pill ${battery.charging ? 'pill--ok' : p <= 15 ? 'pill--danger' : ''}`;

        const secs = battery.charging ? battery.chargingTime : battery.dischargingTime;
        note.textContent = Number.isFinite(secs) && secs > 0
          ? `${hms(secs, true).slice(0, -3)} until ${battery.charging ? 'full' : 'empty'}`
          : battery.charging ? 'Plugged in' : 'Estimating…';
      };

      for (const evt of ['levelchange', 'chargingchange', 'chargingtimechange', 'dischargingtimechange']) {
        ctx.on(battery, evt, render);
      }
      render();
    }).catch(() => {
      note.textContent = 'Battery status unavailable.';
    });
  },
});
