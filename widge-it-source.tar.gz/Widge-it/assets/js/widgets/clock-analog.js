import { defineWidget } from '../core/registry.js';
import { el, fitCanvas, cssVar, icon } from '../core/util.js';

export default defineWidget({
  id: 'clock-analog',
  name: 'Analog Clock',
  category: 'Time',
  size: 'md',
  description: 'Swiss-rail styling with a smooth sweeping second hand.',
  keywords: ['watch', 'hours', 'now'],
  icon: icon('<circle cx="12" cy="12" r="9"/><path d="M12 7.5V12l3 1.8"/>'),

  mount(root, ctx) {
    const canvas = el('canvas');
    const wrap = el('div', { class: 'canvas-wrap' }, canvas);
    const stamp = el('div', { class: 'row row--between', style: { paddingTop: '10px' } }, [
      el('span', { class: 'mono', 'data-ref': 'time', style: { fontSize: '15px', fontWeight: '600' } }),
      el('span', { class: 'tiny dim', 'data-ref': 'date' }),
    ]);
    root.append(wrap, stamp);

    const c2d = canvas.getContext('2d');
    const timeOut = stamp.querySelector('[data-ref="time"]');
    const dateOut = stamp.querySelector('[data-ref="date"]');

    const hand = (angle, length, width, color, back = 0) => {
      c2d.save();
      c2d.rotate(angle);
      c2d.lineWidth = width;
      c2d.strokeStyle = color;
      c2d.lineCap = 'round';
      c2d.beginPath();
      c2d.moveTo(0, back);
      c2d.lineTo(0, -length);
      c2d.stroke();
      c2d.restore();
    };

    function draw() {
      const { w, h } = fitCanvas(canvas, c2d);
      const r = Math.min(w, h) / 2 - 4;
      if (r <= 0) return;

      const text = cssVar('--text', '#fff');
      const dim = cssVar('--text-3', '#888');
      const accent = cssVar('--accent', '#6d8bff');
      const line = cssVar('--line-strong', 'rgba(255,255,255,.2)');

      c2d.clearRect(0, 0, w, h);
      c2d.save();
      c2d.translate(w / 2, h / 2);

      // Dial
      c2d.beginPath();
      c2d.arc(0, 0, r, 0, Math.PI * 2);
      c2d.strokeStyle = line;
      c2d.lineWidth = 1;
      c2d.stroke();

      // Ticks
      for (let i = 0; i < 60; i++) {
        const major = i % 5 === 0;
        c2d.save();
        c2d.rotate((i * Math.PI) / 30);
        c2d.beginPath();
        c2d.moveTo(0, -r + (major ? 11 : 5));
        c2d.lineTo(0, -r + 2);
        c2d.strokeStyle = major ? text : dim;
        c2d.globalAlpha = major ? 0.85 : 0.35;
        c2d.lineWidth = major ? 2 : 1;
        c2d.lineCap = 'round';
        c2d.stroke();
        c2d.restore();
      }

      const now = new Date();
      const ms = now.getMilliseconds() / 1000;
      const s = now.getSeconds() + ms;
      const m = now.getMinutes() + s / 60;
      const hr = (now.getHours() % 12) + m / 60;

      hand((hr * Math.PI) / 6, r * 0.5, 4.5, text, r * 0.1);
      hand((m * Math.PI) / 30, r * 0.72, 3, text, r * 0.12);
      hand((s * Math.PI) / 30, r * 0.8, 1.5, accent, r * 0.2);

      c2d.beginPath();
      c2d.arc(0, 0, 3.2, 0, Math.PI * 2);
      c2d.fillStyle = accent;
      c2d.fill();
      c2d.restore();

      timeOut.textContent = now.toLocaleTimeString(undefined, { hour: '2-digit', minute: '2-digit', second: '2-digit' });
      dateOut.textContent = now.toLocaleDateString(undefined, { weekday: 'short', day: 'numeric', month: 'short' });
    }

    ctx.frame(draw);
  },
});
