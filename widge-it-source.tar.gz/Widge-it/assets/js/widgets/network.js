import { defineWidget } from '../core/registry.js';
import { el, icon } from '../core/util.js';

export default defineWidget({
  id: 'network',
  name: 'Network',
  category: 'System',
  size: 'sm',
  description: 'Connection status, effective type and a round-trip latency probe.',
  keywords: ['online', 'offline', 'latency', 'ping', 'connection', 'wifi'],
  icon: icon('<path d="M2 8.5a16 16 0 0 1 20 0M5 12a11 11 0 0 1 14 0M8.5 15.5a6 6 0 0 1 7 0"/><circle cx="12" cy="19" r="1.2"/>'),

  mount(root, ctx) {
    const status = el('span', { class: 'pill' });
    const latency = el('span', { class: 'metric__value', text: '—' });
    const unit = el('span', { class: 'metric__unit', text: 'ms' });
    const detail = el('div', { class: 'tiny dim' });
    const probe = el('button', { class: 'btn btn--sm', text: 'Probe' });

    root.append(
      el('div', { class: 'row row--between' }, [
        el('div', { class: 'metric' }, [latency, unit]), status,
      ]),
      el('div', { class: 'row row--between', style: { marginTop: 'auto' } }, [detail, probe])
    );

    function renderStatus() {
      const online = navigator.onLine;
      status.textContent = online ? 'Online' : 'Offline';
      status.className = `pill ${online ? 'pill--ok' : 'pill--danger'}`;

      const conn = navigator.connection || navigator.mozConnection || navigator.webkitConnection;
      detail.textContent = conn
        ? `${(conn.effectiveType || '?').toUpperCase()} · ${conn.downlink ?? '?'} Mb/s · rtt ${conn.rtt ?? '?'} ms`
        : 'Connection details unavailable';
    }

    /** Time a same-origin request — no third party involved. */
    async function measure() {
      probe.disabled = true;
      const samples = [];
      for (let i = 0; i < 3; i++) {
        const started = performance.now();
        try {
          const res = await fetch(`${location.pathname}?probe=${Date.now()}-${i}`, { method: 'HEAD', cache: 'no-store' });
          await res.arrayBuffer();   // draining the stream keeps the browser from logging an abort
          samples.push(performance.now() - started);
        } catch {
          latency.textContent = '—';
          probe.disabled = false;
          return;
        }
      }
      const best = Math.min(...samples);
      latency.textContent = best < 10 ? best.toFixed(1) : String(Math.round(best));
      probe.disabled = false;
    }

    probe.addEventListener('click', measure);
    ctx.on(window, 'online', renderStatus);
    ctx.on(window, 'offline', renderStatus);
    ctx.every(5000, renderStatus);
    measure();
  },
});
