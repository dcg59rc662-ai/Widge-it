import { defineWidget } from '../core/registry.js';
import { el, fitCanvas, cssVar, icon, clamp } from '../core/util.js';

export default defineWidget({
  id: 'level',
  name: 'Spirit Level',
  category: 'Sensors',
  size: 'md',
  description: 'Pitch and roll from the motion sensor — hover to demo on desktop.',
  keywords: ['tilt', 'bubble', 'angle', 'gyroscope', 'flat'],
  icon: icon('<rect x="2" y="8" width="20" height="8" rx="3"/><circle cx="12" cy="12" r="2.2"/><path d="M8 10v4M16 10v4"/>'),

  mount(root, ctx) {
    const canvas = el('canvas');
    const wrap = el('div', { class: 'canvas-wrap', style: { touchAction: 'none' } }, canvas);

    const pitchOut = el('span', { class: 'kv__v', text: '0.0°' });
    const rollOut = el('span', { class: 'kv__v', text: '0.0°' });
    const badge = el('span', { class: 'pill' });

    root.append(
      wrap,
      el('div', { class: 'row row--between', style: { paddingTop: '8px' } }, [
        el('span', { class: 'tiny dim', text: 'Level within 1°' }), badge,
      ]),
      el('div', { class: 'kv' }, [el('span', { class: 'kv__k', text: 'Pitch' }), pitchOut]),
      el('div', { class: 'kv' }, [el('span', { class: 'kv__k', text: 'Roll' }), rollOut])
    );

    const c2d = canvas.getContext('2d');
    let pitch = 0, roll = 0;          // targets, degrees
    let sPitch = 0, sRoll = 0;        // smoothed
    let sensor = false;

    const onOrientation = (e) => {
      if (e.beta == null && e.gamma == null) return;
      sensor = true;
      pitch = clamp(e.beta ?? 0, -90, 90);
      roll = clamp(e.gamma ?? 0, -90, 90);
    };
    ctx.on(window, 'deviceorientation', onOrientation);

    // Desktop fallback: drive the bubble from the pointer so the widget is still legible.
    ctx.on(wrap, 'pointermove', (e) => {
      if (sensor) return;
      const r = canvas.getBoundingClientRect();
      roll = ((e.clientX - r.left) / r.width - 0.5) * 60;
      pitch = ((e.clientY - r.top) / r.height - 0.5) * 60;
    });
    ctx.on(wrap, 'pointerleave', () => { if (!sensor) { pitch = 0; roll = 0; } });

    function draw() {
      sPitch += (pitch - sPitch) * 0.15;
      sRoll += (roll - sRoll) * 0.15;

      const { w, h } = fitCanvas(canvas, c2d);
      const r = Math.min(w, h) / 2 - 3;
      if (r <= 0) return;

      const line = cssVar('--line', 'rgba(255,255,255,.1)');
      const lineStrong = cssVar('--line-strong', 'rgba(255,255,255,.2)');
      const accent = cssVar('--accent', '#6d8bff');
      const ok = cssVar('--ok', '#3ddbc0');

      const flat = Math.abs(sPitch) < 1 && Math.abs(sRoll) < 1;
      const colour = flat ? ok : accent;

      c2d.clearRect(0, 0, w, h);
      c2d.save();
      c2d.translate(w / 2, h / 2);

      // Rings
      for (const frac of [1, 0.66, 0.33]) {
        c2d.beginPath();
        c2d.arc(0, 0, r * frac, 0, Math.PI * 2);
        c2d.strokeStyle = frac === 0.33 ? lineStrong : line;
        c2d.lineWidth = 1;
        c2d.stroke();
      }

      // Crosshair
      c2d.beginPath();
      c2d.moveTo(-r, 0); c2d.lineTo(r, 0);
      c2d.moveTo(0, -r); c2d.lineTo(0, r);
      c2d.strokeStyle = line;
      c2d.stroke();

      // Bubble — 45° of tilt reaches the outer ring
      const bx = clamp(sRoll / 45, -1, 1) * r * 0.86;
      const by = clamp(sPitch / 45, -1, 1) * r * 0.86;
      const br = Math.max(7, r * 0.18);

      c2d.beginPath(); c2d.arc(bx, by, br + 5, 0, Math.PI * 2);
      c2d.fillStyle = colour; c2d.globalAlpha = 0.16; c2d.fill(); c2d.globalAlpha = 1;

      c2d.beginPath(); c2d.arc(bx, by, br, 0, Math.PI * 2);
      c2d.fillStyle = colour; c2d.fill();

      c2d.restore();

      pitchOut.textContent = `${sPitch.toFixed(1)}°`;
      rollOut.textContent = `${sRoll.toFixed(1)}°`;
      badge.textContent = flat ? 'Level' : sensor ? 'Tilted' : 'Demo';
      badge.className = `pill ${flat ? 'pill--ok' : sensor ? 'pill--warn' : ''}`;
    }

    ctx.frame(draw);
  },
});
