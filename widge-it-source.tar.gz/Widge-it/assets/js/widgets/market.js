import { defineWidget } from '../core/registry.js';
import { el, fitCanvas, cssVar, icon, smoothLine, rnd } from '../core/util.js';

/* No API key, no network: a seeded random walk that behaves like a price feed.
   Clearly labelled as simulated — swap `tick()` for a real quote source later. */
const TICKERS = [
  { symbol: 'AAPL', name: 'Apple',      price: 228.4,  vol: 0.6 },
  { symbol: 'NVDA', name: 'NVIDIA',     price: 132.9,  vol: 1.4 },
  { symbol: 'MSFT', name: 'Microsoft',  price: 441.2,  vol: 0.5 },
  { symbol: 'BTC',  name: 'Bitcoin',    price: 68420,  vol: 2.1 },
  { symbol: 'ETH',  name: 'Ethereum',   price: 3285,   vol: 1.9 },
];

const HISTORY = 48;

export default defineWidget({
  id: 'market',
  name: 'Market Ticker',
  category: 'Data',
  size: 'lg',
  description: 'Sparkline ticker board driven by a simulated price feed.',
  keywords: ['stocks', 'crypto', 'finance', 'sparkline', 'price'],
  icon: icon('<path d="M3 16l5-5 4 3 6-8"/><path d="M15 6h4v4"/>'),

  mount(root, ctx) {
    const rows = TICKERS.map((t) => {
      const series = [t.price];
      for (let i = 1; i < HISTORY; i++) {
        series.push(Math.max(0.01, series[i - 1] * (1 + rnd(-t.vol, t.vol) / 100)));
      }

      const canvas = el('canvas', { style: { width: '78px', height: '26px' } });
      const price = el('span', { class: 'mono', style: { fontSize: '13px', fontWeight: '600' } });
      const change = el('span', { class: 'mono tiny' });

      const node = el('div', {
        style: { display: 'flex', alignItems: 'center', gap: '10px', padding: '7px 0', borderBottom: '1px solid var(--line)' },
      }, [
        el('div', { style: { width: '54px' } }, [
          el('div', { class: 'small', style: { fontWeight: '650' }, text: t.symbol }),
          el('div', { class: 'tiny dim', text: t.name }),
        ]),
        canvas,
        el('div', { class: 'grow', style: { textAlign: 'right' } }, [price, el('div', {}, change)]),
      ]);

      return { ...t, series, canvas, c2d: canvas.getContext('2d'), price, change, node };
    });

    const head = el('div', { class: 'row row--between', style: { marginBottom: '4px' } }, [
      el('span', { class: 'tiny dim', text: 'Simulated feed · not real market data' }),
      el('span', { class: 'pill pill--accent', 'data-ref': 'clock' }),
    ]);

    const body = el('div', { class: 'fill', style: { overflowY: 'auto' } }, rows.map((r) => r.node));
    root.append(head, body);
    const clock = head.querySelector('[data-ref="clock"]');

    function drawRow(row) {
      const { w, h } = fitCanvas(row.canvas, row.c2d);
      if (w < 4 || h < 4) return;

      const min = Math.min(...row.series);
      const max = Math.max(...row.series);
      const span = max - min || 1;
      const up = row.series.at(-1) >= row.series[0];
      const colour = up ? cssVar('--ok', '#3ddbc0') : cssVar('--danger', '#ff6b81');

      const pts = row.series.map((v, i) => ({
        x: (i / (HISTORY - 1)) * w,
        y: h - 2 - ((v - min) / span) * (h - 4),
      }));

      row.c2d.clearRect(0, 0, w, h);
      row.c2d.beginPath();
      smoothLine(row.c2d, pts);
      row.c2d.strokeStyle = colour;
      row.c2d.lineWidth = 1.5;
      row.c2d.stroke();

      row.c2d.lineTo(w, h); row.c2d.lineTo(0, h); row.c2d.closePath();
      row.c2d.fillStyle = colour;
      row.c2d.globalAlpha = 0.12;
      row.c2d.fill();
      row.c2d.globalAlpha = 1;
    }

    function tick() {
      for (const row of rows) {
        const last = row.series.at(-1);
        row.series.push(Math.max(0.01, last * (1 + rnd(-row.vol, row.vol) / 100)));
        row.series.shift();

        const now = row.series.at(-1);
        const pctChange = ((now - row.series[0]) / row.series[0]) * 100;
        const up = pctChange >= 0;

        row.price.textContent = now.toLocaleString(undefined, {
          minimumFractionDigits: now > 1000 ? 0 : 2, maximumFractionDigits: now > 1000 ? 0 : 2,
        });
        row.change.textContent = `${up ? '▲' : '▼'} ${Math.abs(pctChange).toFixed(2)}%`;
        row.change.style.color = up ? 'var(--ok)' : 'var(--danger)';

        drawRow(row);
      }
      clock.textContent = new Date().toLocaleTimeString(undefined, { hour: '2-digit', minute: '2-digit', second: '2-digit' });
    }

    ctx.every(1500, tick);
    ctx.onTheme(() => rows.forEach(drawRow));
  },
});
