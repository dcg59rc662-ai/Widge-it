import { defineWidget } from '../core/registry.js';
import { el, icon, copy, flash, clamp } from '../core/util.js';

const SETS = {
  lower:   'abcdefghijkmnopqrstuvwxyz',
  upper:   'ABCDEFGHJKLMNPQRSTUVWXYZ',
  digits:  '23456789',
  symbols: '!@#$%^&*()-_=+[]{};:,.?/',
};
const AMBIGUOUS = 'il1Lo0O';

/** Cryptographically random integer in [0, max). */
const randomInt = (max) => {
  const buf = new Uint32Array(1);
  const limit = Math.floor(0xffffffff / max) * max;
  let n;
  do { crypto.getRandomValues(buf); n = buf[0]; } while (n >= limit);
  return n % max;
};

export default defineWidget({
  id: 'password',
  name: 'Password Generator',
  category: 'Tools',
  size: 'md',
  description: 'Crypto-random passwords with a live entropy estimate.',
  keywords: ['security', 'passphrase', 'random', 'entropy', 'generate'],
  icon: icon('<rect x="4" y="10" width="16" height="10" rx="2.5"/><path d="M8 10V7a4 4 0 0 1 8 0v3M12 14v2"/>'),

  mount(root, ctx) {
    const opts = ctx.store.get('opts', { length: 20, upper: true, digits: true, symbols: true, avoid: true });

    const output = el('div', {
      class: 'mono',
      style: {
        wordBreak: 'break-all', fontSize: '15px', fontWeight: '600', lineHeight: '1.45',
        padding: '10px 11px', borderRadius: '10px',
        border: '1px solid var(--line)', background: 'var(--card)', minHeight: '56px',
      },
    });

    const lenLabel = el('span', { class: 'mono tiny' });
    const lenRange = el('input', { class: 'range', type: 'range', min: '8', max: '64', value: String(opts.length), 'aria-label': 'Length' });

    const toggles = el('div', { class: 'row wrap', style: { gap: '5px' } });
    const toggleDefs = [
      ['upper', 'A-Z'], ['digits', '0-9'], ['symbols', '!@#'], ['avoid', 'No look-alikes'],
    ].map(([key, label]) => {
      const btn = el('button', { class: `btn btn--sm${opts[key] ? ' is-on' : ''}`, text: label });
      btn.addEventListener('click', () => {
        opts[key] = !opts[key];
        btn.classList.toggle('is-on', opts[key]);
        save();
      });
      toggles.append(btn);
      return btn;
    });

    const bar = el('div', { class: 'bar__fill', style: { width: '0%' } });
    const strength = el('span', { class: 'pill' });
    const entropy = el('span', { class: 'tiny dim' });
    const note = el('span', { class: 'flash tiny' });

    const regen = el('button', { class: 'btn btn--sm grow', html: `${icon('<path d="M3 12a9 9 0 1 0 2.6-6.4M3 4v5h5"/>')}<span>New</span>` });
    const copyBtn = el('button', { class: 'btn btn--sm btn--primary grow', text: 'Copy' });

    root.append(
      output,
      el('div', { class: 'row row--between', style: { marginTop: '8px' } }, [
        el('span', { class: 'tiny dim', text: 'Length' }), lenLabel,
      ]),
      lenRange,
      toggles,
      el('div', { style: { marginTop: '10px' } }, [
        el('div', { class: 'bar bar--thin', style: { marginBottom: '6px' } }, bar),
        el('div', { class: 'row row--between' }, [strength, entropy]),
      ]),
      el('div', { class: 'row', style: { marginTop: '8px' } }, [regen, copyBtn]),
      el('div', { class: 'row', style: { justifyContent: 'flex-end' } }, note)
    );

    function alphabet() {
      let chars = SETS.lower;
      if (opts.upper) chars += SETS.upper;
      if (opts.digits) chars += SETS.digits;
      if (opts.symbols) chars += SETS.symbols;
      if (!opts.avoid) chars += AMBIGUOUS;
      return [...new Set(chars)].join('');
    }

    function generate() {
      const chars = alphabet();
      let out = '';
      for (let i = 0; i < opts.length; i++) out += chars[randomInt(chars.length)];
      output.textContent = out;

      const bits = opts.length * Math.log2(chars.length);
      const score = clamp(bits / 128, 0, 1);
      bar.style.width = `${score * 100}%`;
      entropy.textContent = `${Math.round(bits)} bits · ${chars.length} symbols`;

      const [label, cls] = bits < 50 ? ['Weak', 'pill--danger']
        : bits < 75 ? ['Fair', 'pill--warn']
        : bits < 100 ? ['Strong', 'pill--ok']
        : ['Excellent', 'pill--ok'];
      strength.textContent = label;
      strength.className = `pill ${cls}`;
    }

    function save() {
      ctx.store.set('opts', opts);
      generate();
    }

    lenRange.addEventListener('input', () => {
      opts.length = Number(lenRange.value);
      lenLabel.textContent = `${opts.length} chars`;
      save();
    });

    regen.addEventListener('click', generate);
    copyBtn.addEventListener('click', async () =>
      flash(note, (await copy(output.textContent)) ? 'Copied to clipboard' : 'Copy failed'));

    lenLabel.textContent = `${opts.length} chars`;
    generate();
  },
});
