# Widge·it

A sleek widget dashboard — 32 self-contained widgets in a filterable, draggable board.
Zero dependencies, zero build step: plain ES modules, plain CSS.

![32 widgets across 7 categories](docs/preview-dark.png)

## Run it

```bash
npm start           # http://localhost:4173
```

Or use any static server (`python3 -m http.server 4173`). It needs to be *served* rather
than opened as a file — ES modules don't load over `file://`.

## The widgets

| Category | Widgets |
| --- | --- |
| **Sensors** | Compass · Spirit Level · Audio Spectrum · Metronome |
| **Time** | Analog Clock · World Clock · Sun Tracker · Moon Phase · Calendar · Countdown · Stopwatch · Time Elapsed |
| **Productivity** | Focus Timer · Task List · Scratchpad · Habit Streak |
| **Tools** | Calculator · Unit Converter · Colour Studio · Password Generator · Gradient Lab · Text Analyser · Tip & Split |
| **System** | Device · Render Monitor · Battery · Network |
| **Data** | Market Ticker · Dice Roller · Daily Quote |
| **Wellbeing** | Breathing · Hydration |

A few worth pointing at:

- **Compass** reads `deviceorientation` for a true magnetic heading, and falls back to a
  draggable rose on desktop (labelled *Manual* so the reading is never mistaken for real).
- **Sun Tracker** computes sunrise, sunset, golden hour and live solar altitude locally
  with NOAA approximations — no weather API, no key. It guesses your city from your time
  zone and can upgrade to a precise fix via *Locate me*.
- **Moon Phase** draws the real terminator for today's lunar age.
- **Market Ticker** is a **simulated** feed, clearly labelled as such — it's there to show
  the sparkline layout, not to quote prices.

### Permissions & environment

These degrade gracefully rather than breaking: Compass and Spirit Level need a motion
sensor (iOS also needs a tap to grant permission, and HTTPS); Audio Spectrum needs
microphone consent; Battery is Chromium-only; Sun Tracker's *Locate me* needs geolocation.
Everything else runs anywhere.

## Using the board

- **Search** — `/` focuses the box; it matches names, categories and keywords.
- **Filter** — category chips across the top.
- **Rearrange** — drag a card by its grip handle. The order is saved.
- **Hide** — the `—` button on a card. *Reset* (top right) brings everything back.
- **Theme** — dark and light, remembered between visits.
- **Density** — comfortable or compact card sizing.

State lives in `localStorage` under the `widgeit:` prefix. Nothing leaves the browser.

## Adding a widget

Drop a file in `assets/js/widgets/` and add one import line to `widgets/index.js`
(that file's order is the default board order):

```js
import { defineWidget } from '../core/registry.js';
import { el, icon } from '../core/util.js';

export default defineWidget({
  id: 'my-widget',              // also its localStorage namespace
  name: 'My Widget',
  category: 'Tools',
  size: 'md',                   // sm | md | tall | wide | lg | xl
  description: 'Shown in the tooltip and matched by search.',
  keywords: ['extra', 'search', 'terms'],
  icon: icon('<circle cx="12" cy="12" r="8"/>'),

  mount(root, ctx) {
    const out = el('div', { class: 'metric__value' });
    root.append(out);
    ctx.every(1000, () => { out.textContent = new Date().getSeconds(); });
  },
});
```

`mount` receives the card body and a context that cleans up after itself when the card is
filtered away or hidden:

| | |
| --- | --- |
| `ctx.every(ms, fn)` | interval that fires immediately |
| `ctx.frame(fn)` | rAF loop, idle while the tab is hidden or the card is off-screen |
| `ctx.next(fn)` | run once after layout settles |
| `ctx.timeout(ms, fn)` | cleaned-up `setTimeout` |
| `ctx.on(target, type, fn)` | cleaned-up listener |
| `ctx.onTheme(fn)` | redraw hook for canvas widgets |
| `ctx.onResize(node, fn)` | `ResizeObserver` hook |
| `ctx.store` | `localStorage` scoped to this widget |
| `ctx.onCleanup(fn)` | anything else to tear down |

Style with the shared primitives in `assets/css/widgets.css` — `.btn`, `.field`, `.select`,
`.range`, `.bar`, `.pill`, `.kv`, `.tabs`, `.metric`, `.list` — so new widgets match the rest
without writing new CSS.

## Layout

```
index.html
assets/
  css/     tokens.css → base.css → app.css → widgets.css
  js/
    core/  app.js (shell, filtering, drag, theme) · registry.js · store.js · util.js
    lib/   astro.js (sun & moon maths) · geo.js (location)
    widgets/  one file per widget + index.js manifest
serve.mjs  dependency-free static server
```

Canvas widgets draw through `fitCanvas()`, which handles device-pixel-ratio scaling, and
read their colours from CSS custom properties so both themes stay correct.
